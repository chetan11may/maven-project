use Data::Dumper;

#
$log = $ARGV[0];
$type = $ARGV[1];
chomp($type);

$html_file = "$type"."_warnings.html";
#print "venu $ENV{'WORKSPACE'}";
#print "D:\\scripts\\$html_file";

open (LOG, "$log") or die "Cannot open the log file $log\n";
$count = 0;
open (HTML, ">$html_file") or die "Cannot create HTML file \n";
print HTML "<HTML>\n";
print HTML "<style>
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
</style>\n";
print HTML "<body>\n";
print HTML "<table border =1  bgcolor=#d1c3b1  width=\"100%\">\n"; 
#print HTML "<tr><th>FILE NAME</th><th>WARNING</th><th>LINE NUMBER</th></tr>\n";
while (<LOG>)
{
	$cnt = $cnt+1;
	if($_ =~/Warning Summary/)
	{
		print "Thisi is the startline-- $cnt\n";
		$start_line = $cnt;
	}
	
	if ($_ =~/Total number of warnings:/)
	{
		print "This is the end line-- $cnt\n";
		$end_line = $cnt;
	}
}
close(LOG);
$cnt = 0;
open (LOG, "$log") or die "Cannot open the log file $log\n";
while (<LOG>)
{
	        if(( $_ =~/: warning: /) && ($type eq "fct" || $type eq "lcp" || $type eq "som"))
        {
                @file_line = split (/warning/);
                #print "$file_line[0]\n";
                $count = ($count+1);
                $entire_line = "$file_line[0]"."--"."$file_line[1]";
                print "$entire_line\n";
                $hash{$entire_line}="$entire_line";
        }

	$cnt = $cnt + 1;
	if(($cnt > $	start_line) && ($cnt < $end_line))
	{
		if($_ =~/: warning:/)
		{
	
			@file_line = split (/: warning:/);
			print "$file_line[0]\n";
			#$count = ($count+1);
			#my $fullfile=`readlink -m '$file_line[0]'`;
                	#chomp $fullfile;
		
			#taking the file name.
			#D@just_file_name  = split(/\//,$file_line[0]);
			#next if($file_line[o] =~/^\/var/);

                	#my $path_root=quotemeta ("$ENV{'PATH_ROOT'}/");
                	#$fullfile =~ s/\A$path_root/..\//;

			$entire_line = "$file_line[0]"."--"."$file_line[1]";
			print "FULLLLL LINENNN---$entire_line\n";	
			$hash{$entire_line}="$entire_line";
			#print "LIne --$_";
		}
	}	
	if(( $_ =~/: warning:/) && ($type eq "BB"))
	{
                @file_line = split (/: warning #/);
                $count = ($count+1);
                $entire_line = "$file_line[0]"."--"."$file_line[1]";
		print "$entire_line\n";
                $hash{$entire_line}="$entire_line";
		
	}
}
#print Dumper(\%hash);

@array=keys(%hash);
$size=$#array+1;
print HTML "<H3>Total Number of warnings= $size</H3>\n";
if($type eq "BB")
{
	print HTML "<tr><th>Sl.Num</th><th>FILE NAME</th><th>WARNING</th></tr>\n";
}
else
{
	print HTML "<tr><th>Sl.Num</th><th>FILE NAME</th><th>WARNING</th><th>LINE NUMBER</th></tr>\n";
}
$count =0;
foreach(keys %hash) 
{ 	
	$count =$count+1;;
	@file_names = split(/--/,$_);
	@names = split(/:/, $file_names[0]);
	$line_count = "$names[1]"."-$names[2]";
	if($type eq "BB")
	{
		print HTML "<tr><td align=left>$count<td align=left>$names[0]</td><td align=left>$file_names[1] </td></tr>\n";
	}
	else
	{
		print HTML "<tr><td align=left>$count<td align=left>$names[0]</td><td align=left>$file_names[1] </td><td align=left>$line_count</td></tr>\n";
	}
	#print "$_ \n";
}
print HTML "</table> \n";
print HTML "</body>\n";
print HTML "</html>\n";


