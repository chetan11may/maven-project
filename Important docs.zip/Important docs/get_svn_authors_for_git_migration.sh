repo_name=$1
wrk_space=$2
authors=$(svn log -q | grep -e '^r' | awk 'BEGIN { FS = "|" } ; { print $2 }' | sort | uniq)
for author in ${authors}; do
  echo "${author} = NAME <USER@DOMAIN>";
  echo  "${author} = ${author} <${author}@nokia.com>" >> ${wrk_space}/${repo_name}_authors.txt
done

#wrk_space is svn chekout loction