ctrl + z--- suspend the job later we can decide we want to run in bg or fg

pip install virtualenv --proxy 10.144.1.10:8080(Proxy is required)

RAJORI GARDEN (RAM CHOLE BHATURE)



<features>
    <module name="BTS_OM">
      <feature id="LTE3656-T-a">
<![CDATA[Adding SYSCOM_GW_LOGICAL_NODE with type Rp3CtrlTunnel]]>      </feature>
    </module>
  </features>

  
  <correctedFaults>
        <module name="SC FLEXI TCOM FSMR4">
            <fault baseline="587410" id="PR295587">
            <![CDATA[PR PR295587 SBTS17A Airscale DM timer stack full with around 800 HSDPA users]]>
            </fault> 
        </module>
  </correctedFaults>d
