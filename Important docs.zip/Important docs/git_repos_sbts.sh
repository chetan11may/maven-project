git init
git remote add origin ssh://ca_gsmbtsscm_dhn@bhgerrit.ext.net.nokia.com:8282/GSM_BTS/GF.git
git config core.sparseCheckout true
cat <<EOM  > ".git/info/sparse-checkout"
bb/C_Application/dsp
bb/C_Application/platform_hw
bb/C_Application/tele
bb/C_Application/tom
bb/C_Application/common
bb/C_Application/ep_common/iua_sctp
bb/C_Application/ep_common/lapd
EOM
git pull origin master
