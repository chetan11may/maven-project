import os
import re
import shutil
import zipfile
import os.path
from optparse import OptionParser
import sys
import tarfile
import datetime
import time
import filecmp
import ftplib
from ftplib import FTP

def Copy_PS_Package(setup_var,PS_Build,binary_file):
	bhlinip = '10.159.236.187'
	bhlinuser = 'ca_swbt'
	bhlinpwd = 'test123'
	localip = '10.43.9.58'
	localuser = 'root'
	localpwd = 'som123'
	setup_var = setup_var.strip()
	complete_path = '/linux_builds/BTS_BUILDS/SBTS/'
	destination_directory= '/root/Test_Builds/PS_Builds'
	destination_directory = destination_directory + '/' + setup_var + '/'

	os.chdir(complete_path)
	files = os.listdir(complete_path)
	ps_zip = PS_Build + '.zip'
	cmd = "ssh "+localuser+"@"+localip+" '"+"mkdir "+destination_directory+PS_Build+"'"
	os.system(cmd)
	try:
		val=os.system("rsync -aruv "+complete_path+ps_zip+" root@10.43.9.58:"+destination_directory+PS_Build+'/'+ps_zip)
		#val=os.system("rsync -aruv "+complete_path+ps_zip+localuser+"@"+localip+":"+destination_directory+PS_Build+'/'+ps_zip)
		time.sleep(30)
		print val," Value"
		if val == 0:
			print "Successfully Copied"
		else:
			print "Failed"
	except:
		sys.exit('Unable to download PS Package')
	try:
		os.system("rsync -aruv "+binary_file+'/dsprtsw.bin'+" root@10.43.9.58:"+destination_directory+PS_Build+'/dsprtsw.bin')

	except:
		print "binary file not found"
		sys.exit("Unable to download DSP Binary")
	size1 = ftp_connect(bhlinip,bhlinuser,bhlinpwd,complete_path,ps_zip)
	size2 = ftp_connect(localip,localuser,localpwd,destination_directory+PS_Build,'/'+ps_zip)
	size3 = ftp_connect(bhlinip,bhlinuser,bhlinpwd,binary_file,'/dsprtsw.bin')
	size4 = ftp_connect(localip,localuser,localpwd,destination_directory+PS_Build,'/dsprtsw.bin')

	if (size1 == size2) and (size3 == size4):
		print("Files copied successfully")
	else:
		print size1," SIZE of PS in Bhlin**************"
		print size2," SIZE of PS in VM**************"
		print size3," SIZE of Bin in Bhlin**************"
		print size4," SIZE of Bin in PS**************"
		sys.exit("File size mismatch")

def ftp_connect(ip,user,pwd,path,file):
	ftp = FTP(ip)
	ftp.login(user,pwd)
	ftp.cwd(path)
	size=ftp.size(path+file)
	ftp.quit()
	return (size)

if __name__ == "__main__":
	keyword_args = {}
	parser = OptionParser()
	parser.add_option("-s", "--setup_var", dest = "setup_var", help = "-s setup_var :- Specify setup variable")
	parser.add_option("-b", "--build", dest = "build", help = "-b build :- Specify build")
	parser.add_option("-d", "--binary", dest = "binary", help = "-d binary :- Specify binary")

	(options, args) = parser.parse_args()


	Copy_PS_Package(options.setup_var,options.build,options.binary)
