#!/bin/bash
# ***************************************************************************************
# File      : commit_to_bb.sh
#
# Purpose   : committing hwapi libraries to bb
#
# Remark    : Syntax: ./commit_to_bb.sh  <SVN_PATH> <PS_VALUE>
#
# Author    : chetan anand
#
# Copyright (C) Nokia 2017
#
# ***************************************************************************************
#usage
if [ $# != 3 ]
   then
        {
        echo -e "USAGE : $0 <Build Type> <PS VALUE> <FSMR TYPE>"
        echo -e "eg :$0 <GF1/trunk or fsmr4/branches/pre_int/PSINT> <PS_VALUE>"
        exit 1
        }
fi

workspace=`pwd`
PS_VAL=$2 #PS integration value
svn_path=$1 #GF1/trunk or fsmr4/branches/pre_int/PSINT
folder_name=$3

setsee LINSEE_PYTHON_2.7.10

rm -rf bb_"$folder_name"_"$PS_VAL"

mkdir bb_"$folder_name"_"$PS_VAL"
cd bb_"$folder_name"_"$PS_VAL"
#svn co https://bhscme.inside.nsn.com/isource/svnroot/BSS_BTS_SW/$svn_path/bb  --username ca_gsmbtsscm --password gsmbtsscm123
git clone  ssh://ca_gsmbtsscm_dhn@bhgerrit.ext.net.nokia.com:8282/GSM_BTS/GF


function copy_libraries
{
cd $workspace

cd /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/CCS_DSP/Services/lib/Nyquist/
rm -rf *
cd /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/DSPHWAPI/Services/lib/Nyquist/
rm -rf *
cd /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/CCS_DSP/Services/lib/KeplerWmp/
rm -rf *
cd /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/DSPHWAPI/Services/lib/KeplerWmp/
rm -rf *

cd $workspace

if (! \cp -rf "$folder_name"_"$PS_VAL"_"FSM3"_HWAPI/C_Platform/CCS_DSP/Services/lib/Nyquist/CGT738/* /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/CCS_DSP/Services/lib/Nyquist/  );
        then
        echo "copying libraries are failing, please check"
        exit 1
fi


if (! \cp -rf "$folder_name"_"$PS_VAL"_"FSM3"_HWAPI/C_Platform/DSPHWAPI/Services/lib/Nyquist/CGT738/* /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/DSPHWAPI/Services/lib/Nyquist/  );
        then
        echo "copying libraries are failing, please check"
        exit 1
fi



if (! \cp -rf "$folder_name"_"$PS_VAL"_"FSM4"_HWAPI/C_Platform/CCS_DSP/Services/lib/KeplerWmp/CGT738/* /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/CCS_DSP/Services/lib/KeplerWmp/  );
        then
        echo "copying libraries are failing, please check"
        exit 1
fi


if (! \cp -rf "$folder_name"_"$PS_VAL"_"FSM4"_HWAPI/C_Platform/DSPHWAPI/Services/lib/KeplerWmp/CGT738/* /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform/DSPHWAPI/Services/lib/KeplerWmp/  );
        then
        echo "copying libraries are failing, Please check"
        exit 1
fi

cd /var/fpwork1/bts_builds/PS_integration/bb_"$folder_name"_"$PS_VAL"/GF/bb/C_Platform

#svn ci -m "updating the libraries for ps $PS_VAL"
git add *
git commit -m "updating the libraries for ps $PS_VAL"
git push origin master 


}


function modify_external
{

cd $workspace/bb_"$folder_name"_"$PS_VAL"/GF/bb


#svn propget svn:externals bb >BB_external.txt
cat build_prep.sh

cd ../../../

#generating Platform Version file for new PS

echo "ECL_PS_REL=$PS_VAL" >bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/new_ECL

for var in `cat bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/ECL |grep -v "PS_REL" |grep -v "C_Application" | cut -d "=" -f1`
        do
                cat /build/ltesdkroot/data/Platforms/PS_REL/$PS_VAL/$PS_VAL/BTS_PS_versionfile_ext.txt | grep "$var" >>bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/new_ECL
        done


cat bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/new_ECL | grep -v "PS_REL" >without_ps_new_platform_versions

cat bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/ECL | grep -v "PS_REL" >without_ps_platform_versions



while read line
do
        var=`echo $line | cut -d "=" -f1`
        echo $var
        new_value=`echo $line | cut -d "=" -f2`
        echo $new_value

        old_value=`cat without_ps_platform_versions | grep "$var" |cut -d "=" -f2`
        echo $old_value

        echo "sed -i "s%"$old_value"%"$new_value"%" bb_"$folder_name"_"$PS_VAL"/GF/bb/build_prep.sh"
        sed -i "s%"$old_value"%"$new_value"%" bb_"$folder_name"_"$PS_VAL"/GF/bb/build_prep.sh

done< without_ps_new_platform_versions


\mv bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/new_ECL bb_"$folder_name"_"$PS_VAL"/GF/bb/ECL/ECL


cd bb_"$folder_name"_"$PS_VAL"
#svn propset svn:externals -F BB_external.txt bb
#svn ci bb -m "adding property sets (externals) for bb and modifying the ECL file"
##git commit.....
}


modify_external

copy_libraries
