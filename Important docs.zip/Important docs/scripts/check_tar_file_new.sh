# ******************************************************************************                       *********
# File      : check_tar_file.sh
#
# Purpose   : Checking the tar file is exist or not proper and send the mail
#
# Remark    : Syntax: check_tar_file.sh
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# ******************************************************************************                       *********

#!/bin/sh

File=`ls -lr *.tar |cut -d' ' -f9`


if [ -f "$File" ] ;
        then
	echo -e "Tar file exist :$File"
	size_check=`ls -lr $File |cut -d' ' -f5`

	echo -e "Size of the Tar file is :$size_check byte"

	if [ "$size_check" -ge 71303168 ] ;
		then
		cp -rf *.tar /var/fpwork/chetan/dummy
		echo -e "copy tar file"
	else
		
		echo -e "tar file is not proper"
		perl send_mail_murali.pl file_not_proper
		exit 1
	fi
else
	echo -e "Tar file isn't exist, please check the build"
	perl send_mail_murali.pl file_doesnt_exist
	exit 1
fi

