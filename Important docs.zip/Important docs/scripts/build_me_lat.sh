#!/bin/bash

##*******************************************************************************
# FILE NAME:
#     build.sh
#
# DESCRIPTION:
#     Script for Generating Build
#
# Product:
#     EP SW
#
# REVISION HISTORY
# Date              Author              REASON
# 04/07/2013        Aashu Gulati        Updated for TRS-SOM integration in SVN.
# 10/05/2013        Aashu Gulati        ME platform specific file created from ME build
#                                       label in clearcase.
#                                       Updated to make code compilable in SVN. 
# 15/05/2012        Divya Ahuja         Deflate using new deflate binary with
#                                       block size 64K        
# 24/02/2012        Nathu Singh         CR052:Added Vegas RFM SW support
#                                       RM0-rfm_scf_file.txt with pl_id 1
#                                       RM4-rfm_sw_info.txt and 
#                                       FRM-PROP file with pl_id 1 
#                                       RM5-FRM-SW file with pl_id 12
# 31/08/2011        Ashish Kumar        Deflate the meswtrx.ehx image 
# 30/08/2011        Hari Krishna        PR 27782ESPE06: Support to .ehx
# 05/08/2011        Ghanshyam Malakar   Implemented SWCR1628 
# 23/06/2011        Ghanshyam Malakar   SWCR: Flash Optimization, Support for RM3:pl_id:1,4,8 
# 22/06/2011        Ghanshyam Malakar   PR27327ESPE07:SWDL flash issue
# 17/05/2011        Ghanshyam Malakar   SWCR: Flash Optimization, Added compile time flag
# 31/03/2011        Deepak Jain          Updated to support SM9 & 
#                                       RM3(New Af File for EX4.1)
# 28/01/2011        Ashish Kumar        PR23089espe06 - Use of Macro instead 
#                                       of direct deflate command
# 28/01/2011        Ashish Kumar        PR23089espe06 - Use of MACRO of 
#                                       deflate instead of direct command
# 21/09/2010        Divya Vij           [EX4A]:meswtrx.ehx has been changed
#                                       again to meswtrx.ehx.bz2.
# 17/09/2010        Divya Vij           [EX4A]:meswtrx.ehx.bz2 has been changed
#                                       to meswtrx.ehx.
# 07/09/2009        Savita Sood      	ME1: RFM File Split Implemented (Ankit Gupta)
#
# 25/08/2009        Utkarsh Malik       Added RMGW task functionality
# 23/04/2009        Vikrant Grover      ME1: Replaced RTCM with RP3M task
# 26/06/2008        Sandeepan Kumar     [EP3]Updated for A5/3 Ciphering feature
# 29/11/2006        Gaurav Das Gupta    pr2985c01 Updated for split in TRS files
#                                       Removed A52 package.Updated AF names
# 24/08/2006        Shweta Vyas         Fixed pronto pr2985C01. 
#                                       Added a support for SM4. 
# 01/06/2006        Hitendra Rawat      corrected path from .../btsom/som to
#                                       .../som also changed names in the 
#                                        script for IR3
# 10/05/2006        Hitendra Rawat      Changed the scripts for new file system
#                                       for IR3
#
# 30/03/2006        Ashish Jain         Added support to create three packages
#                                       A50/A51/A52
# 22/12/2005        Shweta Vyas         Added temporary folder in script(tar_files,srv)
# 17/06/2005        Ashish Jain         Initial Draft
#
# 12/01/2007        Satish Kumar        Changed the file system for new naming
#                                       conventionfor IR4
# 
# 14/02/2007        Priyanka Jindal     Modified to generalize and modularize the file and 
#                                       stores and uses information from text file.   
#
# 21/02/2007        Priyanka Jindal     Modified to check 
#                                        1) To allow user to create selective AFs.  
#                                        2) To check whether all versions are as per format XX.YY-ZZ
#                                        3) To increase support for higher version.
# 
# 28/03/2007        Priyanka Jindal     To generate AFs as per output from Dirk script 
# 
# 09/04/2007        Priyanka Jindal     Modified to do binary comparison by function compare_binary. 
# 10/04/2007        Priyanka Jindal     Modiifed to run script in two modes
#                                         1)Forecfully
#                                         2)By comparing binary 
#
# 11/04/2007        Priyanka Jindal     Modiifed to run script in three modes
#                                         1)Forecfully
#                                         2)By comparing binary with previous build
#                                         3)By comparing binary with baseline build and then 
#                                           with previous build
#
# 
# 12/04/2007        Priyanka Jindal      Updated for logging infomation. 
#
# 17/04/2007        Priyanka Jindal 	 Updated to add debug file information.
# 
# 23/04/2007        Priyanka Jindal      Modified to isolate version and names of files 
#                                        and added baseline parameter.
# 12/06/2007        Priyanka Jindal      Incorporated Review comments
#
# 21/06/2007        Gaurav/Priyanka      Som Binary Splitted
#  
# 27/06/2007        Gaurav/Priyanka      Included FTM Binary split.
#Copyright 2005, NOKIA
#*****************************************************************************
if [ $# != 9 ]
then
        echo "USAGE: ./buildme.sh opt1 opt2 cipher cipher1 version base user_check user_check1 choice
        eg : ./buildme.sh 1 2 5200 5203 05.20-00 01X n y y"
        exit 1
fi
#mode is the build mode release/debug
export opt1=$1;
export opt2=$2;
export cipher=$3;
export cipher1=$4;
export version=$5;
export base=$6;
export user_check=$7;
export user_check1=$8;
export choice=$9;

#echo "user_check";
 DATE=`date +%d%m%y%H%M%S`
 BUILD_PATH=${SVN_ROOT}/som/build
 DEBUG_FILE=${BUILD_PATH}/debug${DATE}.txt
 LOG_FILE=${BUILD_PATH}/log${DATE}.txt
 ERROR_FILE=${BUILD_PATH}/error_log${DATE}.txt
 VERSION_FILE=${BUILD_PATH}/version_file.txt
 INPUT_FILE=${BUILD_PATH}/input${DATE}.txt
 BINARY_FILES=${BUILD_PATH}/binary${DATE}.txt
 TAR=tar
     version_info=`${TAR} --version 2>/dev/null`
     output=`echo ${version_info} | grep -c GNU`
     if test  ${output} = "1"
     then
         TAR=${TAR}' -P --owner=root --group=root --numeric-owner -b1'
     fi

 RM=rm 
 AF_BUILD=ep_tools/bin/af_build
 AF_FILES=${BUILD_PATH}/af_files
 AF_FILES_EP=${BUILD_PATH}/af_files_EP 


#*******************************************************************************
#
#  FUNCTION NAME:    hex_to_dec
#
#  DESCRIPTION:      This function converts hexdecimal value to decimal value. 
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          decimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************



hex_to_dec() {

echo "Entry trace, Function:hex_to_dec, Parameter Passed is: ${*}" >> ${DEBUG_FILE}
  
     first_digit=`echo ${1} | cut -c1-1`
     
     if test ${first_digit} = "A" || test ${first_digit} = "a" 
         then
            first_digit="10"
     elif test ${first_digit} = "B" || test ${first_digit} = "b" 

         then
            first_digit="11"
     elif test ${first_digit} = "C" || test ${first_digit} = "c" 

          then
            first_digit="12"
    elif test ${first_digit} = "D"  || test ${first_digit} = "d" 

         then
            first_digit="13"
    elif test ${first_digit} = "E"  || test ${first_digit} = "e" 

         then
            first_digit="14"
    elif test ${first_digit} = "F" || test ${first_digit} = "f" 

         then
            first_digit="15"
    fi




      second_digit=`echo ${1} | cut -c2-2`
     
     
     if test ${second_digit} = "A" || test ${second_digit} = "a" 
         then
            second_digit="10"
     elif test ${second_digit} = "B" || test ${second_digit} = "b" 

         then
            second_digit="11"
     elif test ${second_digit} = "C" || test ${second_digit} = "c" 

          then
            second_digit="12"
    elif test ${second_digit} = "D"  || test ${second_digit} = "d" 

         then
            second_digit="13"
    elif test ${second_digit} = "E"  || test ${second_digit} = "e" 

         then
            second_digit="14"
    elif test ${second_digit} = "F" || test ${second_digit} = "f" 

         then
            second_digit="15"
    fi

    decimal=`expr ${first_digit} \* 16 + ${second_digit}` 
    if test `echo ${decimal} | wc -c ` -gt 3 
       then 
           echo ${decimal}
    else 
       if test `echo ${decimal} | wc -c` -gt 2 
          then  
              echo "0${decimal}"
       else 
              echo "00${decimal}"  
      fi
   fi


echo "Exit trace, Function:hex_to_dec" >> ${DEBUG_FILE}
}      

#*******************************************************************************
#
#  FUNCTION NAME:    base_no_check
#
#  DESCRIPTION:      This function checks whether baselline enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
base_no_check () { 
     

echo "Entry trace, Function:base_no_check" >> ${DEBUG_FILE}
  while [ /bin/true ]
  do  
#      read base
      if test `echo ${base} | wc -c` -ne 3   
        then 
          echo "Please enter baseline as XX"
           continue
      fi    
      


     first_digit=`echo ${base} | cut -c1-1`
     case  "${first_digit}" in

         [!0-9A-Fa-f]) echo "First digit wrong. Please re-enter value again[0-9 A-F]" 
                        continue  ;;
           
     esac
        

     second_digit=`echo ${base} | cut -c2-2`

     case  "${second_digit}" in

        [!0-9A-Fa-f]) echo "Last digit wrong. Please re-enter value again[0-9 A-F]" 
                      continue  ;;

                  *) break;;
     esac
        
       
done 
 
echo "Exit trace, Function:base_no_check" >> ${DEBUG_FILE}
}
 



#*******************************************************************************
#
#  FUNCTION NAME:    version_check
#
#  DESCRIPTION:      This function checks whether version enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

version_check () { 
     

echo "Entry trace, Function:version_check" >> ${DEBUG_FILE}
  while [ /bin/true ]
  do  
#      read version
      if test `echo ${version} | wc -c` -ne 9 
        then 
          echo "Please enter version as UV.WX-YZ"
           continue
      fi   
      


     u_digit=`echo ${version} | cut -c1-1`
     case  "${u_digit}" in

         [!0]) echo "Wrong value entered for U. 'U' should be zero" 
                        continue  ;;
           
     esac
        
     v_digit=`echo ${version} | cut -c2-2`
     case  "${v_digit}" in

         [!0-9A-Fa-f]) echo "Wrong value entered for V. 'V' should be hexadecimal" 
                        continue  ;;
           
     esac

 
      release=`echo ${version} | cut -c3-3`
      if test ${release} != "."
          then
                echo "Wrong Release Number.Please re-enter value again"
                continue
       
      fi
       
     w_digit=`echo ${version} | cut -c4-4`
     case  "${w_digit}" in

         [!0-9A-Fa-f]) echo "Wrong value entered for W. 'W' should be hexadecimal" 
                        continue  ;;
           
     esac
        
     x_digit=`echo ${version} | cut -c5-5`
     case  "${x_digit}" in

         [!0-9A-Fa-f]) echo "Wrong value entered for X. 'X' should be hexadecimal" 
                        continue  ;;
           
     esac
 
     subrelease=`echo ${version} | cut -c6-6`
        if test ${subrelease} != "-"
            then
                echo "Wrong SubRelease Number.Please re-enter value again"
             
                 continue
        fi 
     

     y_digit=`echo ${version} | cut -c7-7`
     case  "${y_digit}" in

         [!0-9A-Fa-f]) echo "Wrong value entered for Y. 'Y' should be hexadecimal" 
                        continue  ;;
           
     esac
        

     z_digit=`echo ${version} | cut -c8-8`

     case  "${z_digit}" in

        [!0-9A-Fa-f]) echo "Wrong value entered for Z. 'Z' should be hexadecimal" 
                      continue  ;;

                   *) break;;
     esac
        
       
done 
 
echo "Exit trace, Function:version_check" >> ${DEBUG_FILE}
}
 



#*******************************************************************************
#
#  FUNCTION NAME:    ext_check
#
#  DESCRIPTION:      This function checks whether ext and ext1  enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#****************************************************************************
 ext_check () { 
     
 echo "Entry trace, Function:ext_check " >> ${DEBUG_FILE}

 
  while [ /bin/true ]
  do  
#      read extension
      #if test `echo $extension | wc -c` -lt 4 
       # then 
       #   echo "Please enter extenion for package as XXXX"
        #   continue
      #fi    

      if test `echo ${cipher} | wc -c` -ne 5 
        then 
          echo "Please enter extenion for package as XXXX"
           continue

      fi
      break 
 done

echo "Exit trace, Function:ext_check" >> ${DEBUG_FILE}
} 
#****************************************************************************
 ext_check1 () {

 echo "Entry trace, Function:ext_check " >> ${DEBUG_FILE}


  while [ /bin/true ]
  do
#      read extension
      #if test `echo $extension | wc -c` -lt 4
       # then
       #   echo "Please enter extenion for package as XXXX"
        #   continue
      #fi

      if test `echo ${(cipher1} | wc -c` -ne 5
        then
          echo "Please enter extenion for package as XXXX"
           continue

      fi
      break
 done

echo "Exit trace, Function:ext_check" >> ${DEBUG_FILE}
}


#*******************************************************************************
#
#  FUNCTION NAME:    create_ver_file
#
#  DESCRIPTION:      This function creates version file.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

create_ver_file () { 

            

    echo "Entry trace, Function:create_ver_file" >> ${DEBUG_FILE}

    #taking the name of extensions and Package files from user


#    echo "Enter extension for package without ciphering A50:  "
    ext_check
    ext=${cipher}
    
    
  #  echo "Enter extension for package with ciphering A53:  "
    ext_check
    ext_3=${cipher1}
    
#    echo "Enter the version of BTS Package (UV.WX-YZ) "
    version_check  
    pack_version=${version}
 
    
#    echo "Enter Baseline Number"
    #base_no_check
    #read base
    base_no=${base}

   # echo "Do you want to continue with previous Af Versions: yes, no"
 #   read check
    if test ${user_check} = "y" || test ${user_check} = "Y" || test ${user_check} = "yes" \
               || test ${user_check} = "YES"

#if ${user_check} = "y"
       then
     

     btsconf_version=`grep  "BTS Configuration"   ${VERSION_FILE} | cut -d \: -f 2 `
     syspl_version=`grep "SYSPL"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_1=`grep "TAR_1"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_2=`grep "TAR_2"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_3=`grep "TAR_3"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_4=`grep "TAR_4"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_5=`grep "TAR_5"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_6=`grep "TAR_6"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_7=`grep "TAR_7"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_8=`grep "TAR_8"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_9=`grep "TAR_9"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_1=`grep "SOM 1"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_2=`grep "SOM 2"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_3=`grep "SOM 3"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_4=`grep "SOM 4"   ${VERSION_FILE} | cut -d \: -f 2 `
     trx_version_1=`grep "TRX 1"   ${VERSION_FILE} | cut -d \: -f 2 `
     #trx_version_2=`grep "TRX 2"  ${VERSION_FILE} | cut -d \: -f 2 `
     rfm_version=`grep "RFM 1"     ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_1=`grep "RFM 2"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_2=`grep "RFM 3"   ${VERSION_FILE}  | cut -d \: -f 2 `
     # changed for EX4.2 MP1.0
     rfm_version_3=`grep "RFM 0"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_4=`grep "RFM 4"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_5=`grep "RFM 5"   ${VERSION_FILE}  | cut -d \: -f 2 `
     #esea_version=`grep "EM"   ${VERSION_FILE}  | cut -d \: -f 2 `
     
     echo " User selected to continue with same application file versions">>${LOG_FILE}

     

    else
    echo " User selected to change version information">>${LOG_FILE}

    echo "Do you want Af Versions to be same as Pack version: yes, no"
  #  read check
    if test ${user_check1} = "y" || test ${user_check1} = "Y" || test ${user_check1} = "yes" \
               || test ${user_check1} = "YES"
#if ${user_check} = "y"  
     then
           btsconf_version=${pack_version}
           syspl_version=${pack_version}
           trs_version_1=${pack_version}
           trs_version_2=${pack_version}
           trs_version_3=${pack_version}
           trs_version_4=${pack_version}
           trs_version_5=${pack_version}
           trs_version_6=${pack_version}
           trs_version_7=${pack_version}
           trs_version_8=${pack_version}
           trs_version_9=${pack_version}
           som_version_1=${pack_version}
           som_version_2=${pack_version}
           som_version_3=${pack_version}
           som_version_4=${pack_version}
           trx_version_1=${pack_version}
	   #trx_version_2=${pack_version}
           rfm_version=${pack_version}
           rfm_version_1=${pack_version}
           rfm_version_2=${pack_version}
           # changed for EX4.2 MP1.0
           rfm_version_3=${pack_version}
           rfm_version_4=${pack_version}
           rfm_version_5=${pack_version}
	   #esea_version=${pack_version}
            
    echo " User selected to continue with version information as pack Version ">>\
     ${LOG_FILE}


    else 
        echo " User selected to enter new versions for application files ">>\
     ${LOG_FILE}

          
      
         echo "enter the version of BTS Configuration File"
         version_check 
         btsconf_version=${version}
         
         echo "enter the version of SYSPL"
         version_check 
         syspl_version=${version}
 
         echo "enter the version of TAR_1"
         version_check 
         trs_version_1=${version}

         echo "enter the version of TAR_2"
         version_check 
         trs_version_2=${version}
     
         echo "enter the version of TAR_3"
         version_check 
         trs_version_3=${version}

         echo "enter the version of TAR_4"
         version_check 
         trs_version_4=${version}

         echo "enter the version of TAR_5"
             version_check 
             trs_version_5=${version}

         echo "enter the version of TAR_6"
             version_check 
             trs_version_6=${version}

         echo "enter the version of TAR_7"
             version_check 
             trs_version_7=${version}

         echo "enter the version of TAR_8"
             version_check 
             trs_version_8=${version}

         echo "enter the version of TAR_9"
             version_check
             trs_version_9=${version}



         echo "enter the version of SOM 1"
             version_check  
             som_version_1=${version}

         echo "enter the version of SOM 2"
         version_check 
         som_version_2=${version}
        
         echo "enter the version of SOM 3"
         version_check  
         som_version_3=${version}

         echo "enter the version of SOM 4"
         version_check 
         som_version_4=${version}

         echo "enter the version of TRX 1"
         version_check 
         trx_version_1=${version}
         
#echo "enter the version of TRX 2"
#version_check 
#trx_version_2=${version}

         echo "enter the version of RFM1"
         version_check 
         rfm_version=${version}
         
         echo "enter the version of RFM2"
         version_check 
         rfm_version_1=${version}

         echo "enter the version of RFM3"
         version_check 
         rfm_version_2=${version}
         
         # changed for EX4.2 MP1.0

         echo "enter the version of RFM0"
         version_check 
         rfm_version_3=${version}
         echo "enter the version of RFM4"
         version_check 
         rfm_version_4=${version}
         echo "enter the version of RFM5"
         version_check 
         rfm_version_5=${version}

#echo "enter the version of ESEA"
#version_check 
#esea_version=${version}

    
    fi
fi



    echo "The versions enterded are" > ${VERSION_FILE}
    echo "Extension for package with ciphering A50 :${ext}" >> ${VERSION_FILE}
    echo "Extension for package with ciphering A53 :${ext_3}" >> ${VERSION_FILE}
    echo "Baseline Number for package              :${base_no}">> ${VERSION_FILE}
    echo "BTS Package                              :${pack_version}" >>${VERSION_FILE}
    echo "BTS Configuration                        :${btsconf_version}">>${VERSION_FILE}
    echo "SYSPL                                    :${syspl_version}" >>${VERSION_FILE}
    echo "TAR_1                                    :${trs_version_1}">>${VERSION_FILE}
    echo "TAR_2                                    :${trs_version_2}" >>${VERSION_FILE}
    echo "TAR_3                                    :${trs_version_3}" >>${VERSION_FILE}
    echo "TAR_4                                    :${trs_version_4}" >>${VERSION_FILE}
    echo "TAR_5                                    :${trs_version_5}" >>${VERSION_FILE}
    echo "TAR_6                                    :${trs_version_6}" >>${VERSION_FILE}
    echo "TAR_7                                    :${trs_version_7}" >>${VERSION_FILE}
    echo "TAR_8                                    :${trs_version_8}" >>${VERSION_FILE}
    echo "TAR_9                                    :${trs_version_9}" >>${VERSION_FILE}
    echo "SOM 1                                    :${som_version_1}" >>${VERSION_FILE}
    echo "SOM 2                                    :${som_version_2}">>${VERSION_FILE}
    echo "SOM 3                                    :${som_version_3}" >>${VERSION_FILE}
    echo "SOM 4                                    :${som_version_4}">>${VERSION_FILE}
    echo "TRX 1                                    :${trx_version_1}" >>${VERSION_FILE}
    #echo "TRX 2                                   :${trx_version_2}" >>${VERSION_FILE}
    echo "RFM 1                                    :${rfm_version}" >>${VERSION_FILE}
    echo "RFM 2                                    :${rfm_version_1}" >>${VERSION_FILE}
    echo "RFM 3                                    :${rfm_version_2}" >>${VERSION_FILE}
    # changed for EX4.2 MP1.0
    echo "RFM 0                                    :${rfm_version_3}" >>${VERSION_FILE}
    echo "RFM 4                                    :${rfm_version_4}" >>${VERSION_FILE}
    echo "RFM 5                                    :${rfm_version_5}" >>${VERSION_FILE}
    #echo "EM                                      :${esea_version}" >>${VERSION_FILE}

    cat ${VERSION_FILE}  >> ${LOG_FILE}


echo "Exit trace, Function:create_ver_file" >> ${DEBUG_FILE}
}
#*******************************************************************************
#
#  FUNCTION NAME:    print_func
#
#  DESCRIPTION:      This function prints data in a format.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
print_func () { 


file_name=`ls $1 | grep ${2}_*`
echo "*******************************************">> \
      ${BUILD_PATH}/btspack_${pack_version}/btspack_log

echo "Copying $file_name from ${1} folder">> \
       ${BUILD_PATH}/btspack_${pack_version}/btspack_log

echo "*******************************************">> \
      ${BUILD_PATH}/btspack_${pack_version}/btspack_log
  



}


#*******************************************************************************
#
#  FUNCTION NAME:    del_func
#
#  DESCRIPTION:      This function deletes directory/file if it exists.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


del_func() {


echo "Entry trace, Function:del_func called to delete ${1}, if it already exists " >> \
      ${DEBUG_FILE} 
 #dir_name=`ls | grep $1`
  #   if test "$1" = "$dir_name"
   #      then
 
              ${RM} -rf ${1} 2>/dev/null 
    # fi 


echo "Exit trace, Function:del_func" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    compare_binary
#
#  DESCRIPTION:      This function do comparison of binaries using md5sum.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


compare_binary () {


echo "Entry trace, Function:compare_binary, Compares : ${1} ${2} in folder ${3}" >> ${DEBUG_FILE}
AF_FOLDER=${3}
TAR_PATH=${BUILD_PATH}/tar_files

cd ${BUILD_PATH}/
del_func tmp

mkdir ${BUILD_PATH}/tmp
mkdir ${BUILD_PATH}/tmp/bzip_af
mkdir ${BUILD_PATH}/tmp/bzip_tar

mkdir ${BUILD_PATH}/tmp/bzip_af/tar 
mkdir ${BUILD_PATH}/tmp/bzip_tar/tar 


echo "*******************************"  >> ${BINARY_FILES}
echo "Listing changed binaries in $1" >> ${BINARY_FILES}
echo "*******************************"  >> ${BINARY_FILES}

flag1=2
null_string=" " 
cp ${TAR_PATH}/${2}* ${BUILD_PATH}/tmp/bzip_tar/

cp ${AF_FOLDER}/${1}* ${BUILD_PATH}/tmp/${1} >& ${ERROR_FILE}
if test "${?}" != "0"
   then 
          flag1=1
          echo "Application file doesn't exists in folder ${AF_FOLDER} " >>  ${DEBUG_FILE}

else            
           tail +257c ${BUILD_PATH}/tmp/${1} > ${BUILD_PATH}/tmp/bzip_af/${1}


           bzip2 -d ${BUILD_PATH}/tmp/bzip_af/${1}  >& ${ERROR_FILE}
           bzip2 -d ${BUILD_PATH}/tmp/bzip_tar/${2}* >& ${ERROR_FILE}


          cd ${BUILD_PATH}/tmp/bzip_af/tar/
          if [ ! -f   ${BUILD_PATH}/tmp/bzip_af/${1}.out ]
          then
             ${TAR} -xf ${BUILD_PATH}/tmp/bzip_af/${1}
             rm ${BUILD_PATH}/tmp/bzip_af/${1}
          else
             ${TAR} -xf ${BUILD_PATH}/tmp/bzip_af/${1}.out 
             rm ${BUILD_PATH}/tmp/bzip_af/${1}.out
          fi
          
          cd ${BUILD_PATH}/tmp/bzip_tar/tar/
          ${TAR} -xf ${BUILD_PATH}/tmp/bzip_tar/${2}*.tar 
          rm ${BUILD_PATH}/tmp/bzip_tar/${2}*.tar
          
          dir=${BUILD_PATH}/tmp/bzip_tar
          #read a           
          count=`find ${dir} ! -type d | wc -l`
          #find $dir ! -type d -print
          #echo "count of file $count"
 
          cd ${BUILD_PATH}/tmp/bzip_af
          count1=`find . ! -type d | wc -l`
          #find . ! -type d -print
     
          #echo "count of file in tar $count1" 
          
          diff_count=`expr ${count}  - ${count1}`
          if test ${diff_count} != 0
            then 
                 #echo "files diferent"
                 flag1=1
                 echo "Number of binaries different" >>${DEBUG_FILE}
                 echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}
                 echo "Binary Moved in/out of Application file ${1}" >> ${BINARY_FILES}
          else 
 
          echo " Checksum of AF files binary     Checksum of Tar file binary    file name"  >>\
          ${DEBUG_FILE}
          for file in `find .  ! -type d -print`
          do
               info_file=`echo ${file}| grep info`
               if test "${?}" !=  "0"  
                   then
                      chksum1=`${SVN_ROOT}/apps/gnu/SunOS/bin/md5sum ${file}`
                      chksum1=`echo ${chksum1} | cut -d " " -f -1`
                      
                      if [ ! -f   ${dir}/${file} ]
                         then 
                             flag1=1
                              echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}

                             echo "Binary ${file} moved out of AF file" >>\
                                 ${DEBUG_FILE}
                      else   
                             chksum=`${SVN_ROOT}/apps/gnu/SunOS/bin/md5sum ${dir}/${file}`
                             chksum=`echo ${chksum} | cut -d " " -f -1`
                             #echo "$chksum $chksum1 $file"
                             echo "${chksum1}    ${chksum}     ${file}">>${DEBUG_FILE}
                             if test ${chksum1} = ${chksum}
                                 then
                                   #flag1=2   
                                   #echo $flag1 
                                   echo "............."  >>${DEBUG_FILE}
 
                             else 
                                   flag1=1
                                   echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}
                                   echo "${file} changed" >> ${BINARY_FILES}
                                  #break
                             fi
                      fi
               fi
           
      
        done
   fi

 fi
echo "Exit trace, Function:compare_binary" >> ${DEBUG_FILE} 

}


#*******************************************************************************
#
#  FUNCTION NAME:    binary_init
#
#  DESCRIPTION:      This function initiate comparison of binaries.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
binary_init () {

echo "Entry trace, Function:binary_init Parameter Passed : ${@}" >> ${DEBUG_FILE}

if test ${1} = "2"

then

      compare_binary ${2} ${3} ${AF_FILES}
      flag=${flag1}
      if test  "${flag}" = "1" 
          then 
              echo "${2}_IR04.A5X :changed" >> ${INPUT_FILE}
      else  
              echo "${2}_IR04.A5X :unchanged" >> ${INPUT_FILE}
               echo "No files associated with ${2} changed" >> ${BINARY_FILES}


      fi

fi

if  test ${1} = "3"

then

            compare_binary ${2} ${3} ${AF_FILES_EP}
            flag=${flag1}
            if test  "${flag}" =  "1" 
                then 
                    compare_binary ${2} ${3} ${AF_FILES}
                    flag=${flag1}   

                    if test  "${flag}" =  "1" 
                         then 
                             echo "${2}_IR04.A5X :changed" >> ${INPUT_FILE}

                    else  
                             echo "${2}_IR04.A5X :2" >> ${INPUT_FILE}
                             echo "No files associated with ${2} changed" >> ${BINARY_FILES}

                    fi
          else  
                    echo "${2}_IR04.A5X :1" >> ${INPUT_FILE}
                    echo "No files associated with ${2} changed" >> ${BINARY_FILES}
          fi

fi





}

#*******************************************************************************
#
#  FUNCTION NAME:    secure_command
#
#  DESCRIPTION:      This function checks whether command executed successfully or not.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


secure_command () {


echo "Entry trace, Function:secure_command command to execute is: ${@}" >> ${DEBUG_FILE}

${@}
if test ${?} -ne 0
   then 
       echo " command ${@} is not successfull. Please check and re-run script"
       exit
fi 
echo "Exit trace, Function:secure_command" >> ${DEBUG_FILE}



}


#*******************************************************************************
#
#  FUNCTION NAME:    af_file_create
#
#  DESCRIPTION:      This function will generate AF file based on input file.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE; 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


af_file_create () { 


echo "Entry trace, Function:af_file_create Parameter Passed are: ${*}" >> ${DEBUG_FILE}

check=`grep "${1}" ${INPUT_FILE} |  cut -d \: -f 2`
if test "${check}" != changed

         then
            if test "${check}" = "1"          
                then
  
                       secure_command cp ${AF_FILES_EP}/${1}*  ${TAR_PATH}/
                       print_func  ${AF_FILES_EP} ${1}
                
            else 
                       print_func  ${AF_FILES} ${1}
                       secure_command cp  ${AF_FILES}/${1}*  ${TAR_PATH}/
            fi
else

          secure_command ../${AF_BUILD} -r"${ext}""${2}" -n${3} -e${4} -V${5} \
              ${6} >> ${BUILD_PATH}/btspack_${pack_version}/btspack_log

 
fi

echo "Exit trace, Function:af_file_create" >> ${DEBUG_FILE}
}
 
#*******************************************************************************
#
#  FUNCTION NAME:    create_build
#
#  DESCRIPTION:      This function creates build package.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          decimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

create_build () {

    
     TRX_PATH=${BUILD_PATH}
     SOM_PATH=${SVN_ROOT}/som
     RFM_PATH=${BUILD_PATH}
     FTM_PATH=${SVN_ROOT}/itrBuild/ntoarmbe_wp/image/swdownload

     # changed by hitendra singh rawat
     CONF_PATH=${BUILD_PATH}
     MF_BUILD=ep_tools/bin/mf_build
     CONFIG_BUILD=${BUILD_PATH}/ep_tools/bin
     SRV_PATH=${SVN_ROOT}/itrBuild/ntoarmbe_wp/image/swdownload
     PROC=`eval uname`
	if [ "$PROC" == Linux ]
	then
		   STRIP="${EX_TOOLS_DIR}/apps/qnx632/host/linux/x86/usr/ntoarm/bin/strip"
     		   DEFLATE="${EX_TOOLS_DIR}/apps/qnx632/host/linux/x86/usr/bin/newqnxdeflate/deflate"
	
      else

	     STRIP="${EX_TOOLS_DIR}/apps/qnx/host/solaris/sparc/usr/ntoarm/bin/strip"
     	     DEFLATE="${EX_TOOLS_DIR}/apps/qnx/host/solaris/sparc/usr/bin/newqnxdeflate/deflate"
	fi	
#ESEA_PATH=${BUILD_PATH}
     #config file
     
     echo "Entry trace, Function:create_build Parameter Passed: $@" > ${DEBUG_FILE}            
     #Added by Hitendra Singh Rawat
     cd ${BUILD_PATH}/
  
     del_func som
     secure_command mkdir ${BUILD_PATH}/som/
     secure_command mkdir ${BUILD_PATH}/som/bin 
     secure_command mkdir ${BUILD_PATH}/som/dll
	 	 secure_command mkdir ${BUILD_PATH}/som/rfm
     secure_command mkdir ${BUILD_PATH}/som/trx
	#secure_command mkdir ${BUILD_PATH}/som/esea
     

     # copy all som trx rtc files 
     echo "Copying SOM binaries to ${BUILD_PATH}/som/bin/"
     echo "this may take a while... "

     secure_command cp ${BUILD_PATH}/trx/* ${BUILD_PATH}/som/trx
     secure_command cp -rf ${BUILD_PATH}/rfm/* ${BUILD_PATH}/som/rfm/
     if test "$2" = "1" || test "$2" = "2"
     then
     secure_command cp -rf ${BUILD_PATH}/rfm/FRM-SW_040211*.LAR ${BUILD_PATH}/../
     secure_command cp -rf ${BUILD_PATH}/rfm/vegas/FRM-SW_060211*.LAR ${BUILD_PATH}/../
     fi
     secure_command cp ${SOM_PATH}/dll/libsom* ${BUILD_PATH}/som/dll
     secure_command cp ${SOM_PATH}/bin/som* ${BUILD_PATH}/som/bin
     secure_command cp ${SOM_PATH}/bin/me/som* ${BUILD_PATH}/som/bin
	 #secure_command cp ${BUILD_PATH}/esea/* ${BUILD_PATH}/som/esea 
     echo "Copying done!"
     echo "Copied binaries into ${BUILD_PATH}/som/ " >> ${DEBUG_FILE}    
     #make a temporary "tar_files" folder
     del_func tar_files
     secure_command mkdir ${BUILD_PATH}/tar_files
     TAR_PATH=${BUILD_PATH}/tar_files

     #make a temporary "srv" folder
     cd ${SRV_PATH}/
     del_func srv
     secure_command mkdir ${SRV_PATH}/srv

     #clean tar_files folder ${BUILD_PATH}/btspack_log

     cd ${TAR_PATH}
     secure_command ${RM} -rf *.*
 
     echo "Checked whether version file exists or not............" >> ${DEBUG_FILE}   
	 if test -e ${VERSION_FILE}
        then  
          echo "The versions for new AFs will be:"    

     else
         echo "Version File or AF Build Option file doesn't exists."
         create_ver_file

     fi


    
     ext=`grep A50 ${VERSION_FILE} | cut -d \: -f 2`
     ext_3=`grep "A53" ${VERSION_FILE} | cut -d \: -f 2`
     base_no=`grep "Baseline" ${VERSION_FILE} | cut -d \: -f 2`

     pack_version=`grep  "BTS Package" ${VERSION_FILE} | cut -d \: -f 2 ` 
     btsconf_version=`grep  "BTS Configuration"   ${VERSION_FILE} | cut -d \: -f 2 `
     syspl_version=`grep "SYSPL"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_1=`grep "TAR_1"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_2=`grep "TAR_2"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_3=`grep "TAR_3"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_4=`grep "TAR_4"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_5=`grep "TAR_5"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_6=`grep "TAR_6"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_7=`grep "TAR_7"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_8=`grep "TAR_8"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_9=`grep "TAR_9"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_1=`grep "SOM 1"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_2=`grep "SOM 2"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_3=`grep "SOM 3"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_4=`grep "SOM 4"   ${VERSION_FILE} | cut -d \: -f 2 `
     trx_version_1=`grep "TRX 1"   ${VERSION_FILE} | cut -d \: -f 2 `
	#trx_version_2=`grep "TRX 2"   ${VERSION_FILE} | cut -d \: -f 2 `
     rfm_version=`grep "RFM 1"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_1=`grep "RFM 2"   ${VERSION_FILE}  | cut -d \: -f 2 `

     rfm_version_2=`grep "RFM 3"   ${VERSION_FILE}  | cut -d \: -f 2 `
     #Changed for EX4.2 MP1.0
     rfm_version_3=`grep "RFM 0"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_4=`grep "RFM 4"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_5=`grep "RFM 5"   ${VERSION_FILE}  | cut -d \: -f 2 `
	#esea_version=`grep "EM"   ${VERSION_FILE}  | cut -d \: -f 2 `
 
    
     echo "Extension for package with ciphering A50 :${ext}" 
     echo "Extension for package with ciphering A53 :${ext_3}" 
     echo "Baseline Number for package              :${base_no}" 
     echo "BTS Package                              :${pack_version}"
     echo "BTS Configuration                        :${btsconf_version}"
     echo "SYSPL                                    :${syspl_version}"
     echo "TAR_1                                    :${trs_version_1}"
     echo "TAR_2                                    :${trs_version_2}"
     echo "TAR_3                                    :${trs_version_3}"
     echo "TAR_4                                    :${trs_version_4}"
     echo "TAR_5                                    :${trs_version_5}"
     echo "TAR_6                                    :${trs_version_6}"
     echo "TAR_7                                    :${trs_version_7}"
     echo "TAR_8                                    :${trs_version_8}"
     echo "TAR_9                                    :${trs_version_9}"
     echo "SOM 1                                    :${som_version_1}"
     echo "SOM 2                                    :${som_version_2}"
     echo "SOM 3                                    :${som_version_3}"
     echo "SOM 4                                    :${som_version_4}"
     echo "TRX 1                                    :${trx_version_1}"
#echo "TRX 2                                    :${trx_version_2}"
     echo "RFM 1                                     :${rfm_version}"
     echo "RFM 2                                     :${rfm_version_1}"
     echo "RFM 3                                     :${rfm_version_2}"
     #Changed for EX4.2 MP1.0
     echo "RFM 0                                     :${rfm_version_3}"   
     echo "RFM 4                                     :${rfm_version_4}"   
     echo "RFM 5                                     :${rfm_version_5}"   
#echo "EM                                       :${esea_version}"
 
 #    echo "Do you want to continue with same version (y/n)?"
#     read choice
     if test ${choice} = "n" || test ${choice} = "N" || test ${choice} = "no"  \
                || test ${choice} = "NO"
     then    
            echo " User selected to enter new versions">>${LOG_FILE}

             create_ver_file
     else
           echo " User selected to continue with same version information">>${LOG_FILE}  
   fi 


     #Taking last 2 digits for changing from hexadecimal to decimal format
 
     #ext_BTS_CFG=`echo ${pack_version} | cut -c7-8`
     #ext_SM1_SM5=`echo ${trs_version_1} | cut -c7-8`
     #ext_SO1_SO2=`echo ${som_version_1} | cut -c7-8`
     #ext_RM=`echo ${rtc_version} | cut -c7-8`
     #ext_TM=`echo ${rtc_version} | cut -c7-8`
 
    
     pack_version_3=`echo ${pack_version} | cut -c1-7`3
     #echo ${pack_version_3} 
     btsconf_version_3=`echo ${btsconf_version} | cut -c1-7`3

     
     base_no_dec=$base
     #echo ${base_no_dec}
     #Chnaging hexadecimal value to decimal
     ext_BTS_CFG_dec=${base_no_dec} #`hex_to_dec $ext_BTS_CFG`

    
     #Chnaging hexadecimal value to decimal for FTM
     ext_SM1_SM5_dec=${base_no_dec} #`hex_to_dec $ext_SM1_SM5`

     #Chnaging hexadecimal value to decimal for SOM
     ext_SO1_SO2_dec=${base_no_dec} #`hex_to_dec $ext_SO1_SO2`


     #Chnaging hexadecimal value to decimal for RFM
     
     ext_RM_dec=${base_no_dec} #`hex_to_dec $ext_RM` 

 
     #Chnaging hexadecimal value to decimal for TRX
     ext_TM_dec=${base_no_dec} #`hex_to_dec $ext_TM`


     #Changing hexadecimal value to decimal for ESEA
#ext_EM_dec=$base_no_dec #`hex_to_dec $ext_EM`


     cd ${BUILD_PATH}
     del_func btspack_${pack_version}
     del_func btspack_${pack_version_3}

     secure_command mkdir btspack_${pack_version}
     secure_command mkdir btspack_${pack_version_3} 
     secure_command mkdir btspack_${pack_version}/A50
     secure_command mkdir btspack_${pack_version_3}/A53
 
    #Create TRS and SYS PL tar and copy it in tar_files directory */
     echo "make_sys_trs_pkg.pl script running........... " >> ${DEBUG_FILE}   
     cd ${SVN_ROOT}/itr/integration/scripts
     perl ${BUILD_PATH}/make_sys_trs_pkg.pl SM1M${ext}.${ext_SM1_SM5_dec} \
     SM2M${ext}.${ext_SM1_SM5_dec} SM3M${ext}.${ext_SM1_SM5_dec}           \
     SM4M${ext}.${ext_SM1_SM5_dec} SM5M${ext}.${ext_SM1_SM5_dec}\
     SM6M${ext}.${ext_SM1_SM5_dec} SM7M${ext}.${ext_SM1_SM5_dec} \
     SM8M${ext}.${ext_SM1_SM5_dec} SM9M${ext}.${ext_SM1_SM5_dec} \
     SMAM${ext}.${ext_SM1_SM5_dec} -compress 
     
     echo "make_sys_trs_pkg.pl script completed.......... " >> ${DEBUG_FILE} 
     secure_command cp ${FTM_PATH}/Sys_PL.tar ${TAR_PATH}/. 
     secure_command cp ${FTM_PATH}/TAR_1.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_2.tar ${TAR_PATH}/. 
     secure_command cp ${FTM_PATH}/TAR_3.tar ${TAR_PATH}/. 
     secure_command cp ${FTM_PATH}/TAR_4.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_5.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_6.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_7.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_8.tar ${TAR_PATH}/.
     secure_command cp ${FTM_PATH}/TAR_9.tar ${TAR_PATH}/.
     #Create TRX tar and copy it in tar_files directory 
     #****************TRX TARS**********************#
     #**********************************************#
     #**********************************************#
     #**********************************************#
        
     cd ${BUILD_PATH}
     secure_command ${DEFLATE} -b64 som/trx/meswtrx.ehx
     secure_command ${TAR} -cf ${TAR_PATH}/trx1.tar som/trx/meswtrx.ehx
     secure_command mkdir som/srv
     
     secure_command ${TAR} -tvf ${TAR_PATH}/trx1.tar > som/srv/TM1M${ext}.${ext_TM_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/trx1.tar som/srv/TM1M${ext}.${ext_TM_dec}.info
     secure_command ${RM} -rf som/srv

     echo "Tarred trx binary" >> ${DEBUG_FILE}  

     secure_command bzip2 --best ${TAR_PATH}/trx1.tar
          
     echo "bzipped trx binary" >> ${DEBUG_FILE}  



     #Create TRX tar and copy it in tar_files directory 
     #****************TRX TARS**********************#
     #**********************************************#
     #**********************************************#
     #**********************************************#
        
#cd ${BUILD_PATH}
#    secure_command ${TAR} -cf ${TAR_PATH}/trx2.tar som/trx/odswtrx.ehx
     #secure_command mkdir som/srv
     
#    secure_command ${TAR} -tvf ${TAR_PATH}/trx2.tar > som/srv/TM2_${ext}.${ext_TM_dec}.info
#    secure_command ${TAR} -rf ${TAR_PATH}/trx2.tar som/srv/TM2_${ext}.${ext_TM_dec}.info
#    secure_command ${RM} -rf som/srv

#     echo "Tarred trx binary" >> ${DEBUG_FILE}  

#    secure_command bzip2 --best ${TAR_PATH}/trx2.tar
          
#    echo "bzipped trx binary" >> ${DEBUG_FILE}  

 

 
     #Create SOM tar and copy it in tar_files directory */
     #****************SOM TARS**********************#
     #**********************************************#
     #**********************************************#
     #**********************************************# 

     cd ${BUILD_PATH}
     mkdir som/srv
     secure_command ${STRIP} som/bin/som* som/dll/libsom*
     secure_command ${DEFLATE} -b64 ${BUILD_PATH}/som/bin/*
     secure_command ${DEFLATE} -b64 ${BUILD_PATH}/som/dll/*


     secure_command ${TAR} -cf ${TAR_PATH}/som1.tar  som/bin/som_llc \
          som/bin/som_persm  som/bin/som_qdl  som/bin/som_lapd  som/bin/som_iua_sctp
    
     secure_command ${TAR} -tvf ${TAR_PATH}/som1.tar >  som/srv/SO1M${ext}.${ext_SO1_SO2_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/som1.tar  som/srv/SO1M${ext}.${ext_SO1_SO2_dec}.info
      
     secure_command ${TAR} -cf ${TAR_PATH}/som2.tar som/bin/som_hwmgt\
        som/bin/som_q1mgt som/bin/som_testm
     secure_command ${TAR} -tvf ${TAR_PATH}/som2.tar > som/srv/SO2M${ext}.${ext_SO1_SO2_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/som2.tar som/srv/SO2M${ext}.${ext_SO1_SO2_dec}.info
   

     secure_command ${TAR} -cf ${TAR_PATH}/som3.tar  som/bin/som_btsrv som/bin/som_rp3m \
     som/bin/som_tcs som/dll/libsom*
     secure_command ${TAR} -tvf ${TAR_PATH}/som3.tar > som/srv/SO3M${ext}.${ext_SO1_SO2_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/som3.tar som/srv/SO3M${ext}.${ext_SO1_SO2_dec}.info


     secure_command ${TAR} -cf ${TAR_PATH}/som4.tar   som/bin/som_ah som/bin/som_bc \
              som/bin/som_build_info som/bin/som_commis som/bin/som_rmgw
     secure_command ${TAR} -tvf ${TAR_PATH}/som4.tar > som/srv/SO4M${ext}.${ext_SO1_SO2_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/som4.tar som/srv/SO4M${ext}.${ext_SO1_SO2_dec}.info
         

     secure_command ${RM} -rf som/srv


     echo "Tarred som1 binary" >> ${DEBUG_FILE}  
     #secure_command bzip2 --best ${TAR_PATH}/som1.tar
     echo "Bzipped som1 binary" >> ${DEBUG_FILE}  

     echo "Tarred som2 binary" >> ${DEBUG_FILE}  
     #secure_command bzip2 --best ${TAR_PATH}/som2.tar
     echo "Bzipped som2 binary" >> ${DEBUG_FILE}  
         
     echo "Tarred som3 binary" >> ${DEBUG_FILE}  
     #secure_command bzip2 --best ${TAR_PATH}/som3.tar
     echo "Bzipped som3 binary" >> ${DEBUG_FILE}  

     echo "Tarred som4 binary" >> ${DEBUG_FILE}  
     #secure_command bzip2 --best ${TAR_PATH}/som4.tar
     echo "Bzipped som4 binary" >> ${DEBUG_FILE}  
     
     #Create RFM tar and copy it in tar_files directory */
     #****************RFM TARS**********************#
     #**********************************************#
     #**********************************************#
     #**********************************************#   
     
     cd $RFM_PATH
     secure_command ${TAR} -cvf ${TAR_PATH}/rfm1.tar som/rfm/FRM-PROP_*.LAR som/rfm/rfm_sw_info.txt
     secure_command mkdir som/srv
     secure_command ${TAR} -tvf ${TAR_PATH}/rfm1.tar > som/srv/RM1M${ext}.${ext_RM_dec}.info
     if test "$2" = "2"
     then
         cd $RFM_PATH/../
         secure_command ${TAR} -cf ${TAR_PATH}/rfm3.tar FRM-SW_040211*.LAR
         cd $RFM_PATH
         secure_command ${TAR} -tvf ${TAR_PATH}/rfm3.tar > som/srv/RM3M${ext}.${ext_RM_dec}.info
         secure_command ${TAR} -rf ${TAR_PATH}/rfm1.tar som/srv/RM1M${ext}.${ext_RM_dec}.info som/srv/RM3M${ext}.${ext_RM_dec}.info
         secure_command ${RM} -rf ${TAR_PATH}/rfm3.tar
         secure_command ${RM} -rf ../FRM-SW_040211*.LAR
     else
     secure_command ${TAR} -rf ${TAR_PATH}/rfm1.tar som/srv/RM1M${ext}.${ext_RM_dec}.info
     fi
     secure_command ${RM} -rf som/srv
     echo "Tarred rfm binary" >> ${DEBUG_FILE}  
     secure_command bzip2 --best ${TAR_PATH}/rfm1.tar
     echo "bzipped rfm binary" >> ${DEBUG_FILE}  

     cd $RFM_PATH
     secure_command ${TAR} -cf ${TAR_PATH}/rfm2.tar som/rfm/FRM-ME1_*.LAR
     secure_command mkdir som/srv
     secure_command ${TAR} -tvf ${TAR_PATH}/rfm2.tar > som/srv/RM2M${ext}.${ext_RM_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/rfm2.tar som/srv/RM2M${ext}.${ext_RM_dec}.info
     secure_command ${RM} -rf som/srv
     echo "Tarred rfm binary" >> ${DEBUG_FILE}  
     secure_command bzip2 --best ${TAR_PATH}/rfm2.tar
     echo "bzipped rfm binary" >> ${DEBUG_FILE} 

     cd $RFM_PATH
     if test "$2" = "1"
     then
        secure_command ${TAR} -cf ${TAR_PATH}/rfm3.tar ../FRM-SW_040211*.LAR
        secure_command mkdir som/srv
        secure_command ${TAR} -tvf ${TAR_PATH}/rfm3.tar > som/srv/RM3M${ext}.${ext_RM_dec}.info
        secure_command ${TAR} -rf ${TAR_PATH}/rfm3.tar som/srv/RM3M${ext}.${ext_RM_dec}.info
        secure_command ${RM} -rf som/srv
        secure_command ${RM} -rf ../FRM-SW_040211*.LAR
        echo "Tarred rfm binary" >> ${DEBUG_FILE}
        secure_command bzip2 --best ${TAR_PATH}/rfm3.tar
        echo "bzipped rfm binary" >> ${DEBUG_FILE}
     else
        if test "$2" = "2"
        then
            secure_command cp som/rfm/FRM-SW_040211*.LAR ${TAR_PATH}/.
            echo "Copied FRM_SW LAR file" >> ${DEBUG_FILE}
        else
            secure_command ${TAR} -cf ${TAR_PATH}/rfm3.tar som/rfm/FRM-SW_040211*.LAR
            secure_command mkdir som/srv
            secure_command ${TAR} -tvf ${TAR_PATH}/rfm3.tar > som/srv/RM3M${ext}.${ext_RM_dec}.info
            secure_command ${TAR} -rf ${TAR_PATH}/rfm3.tar som/srv/RM3M${ext}.${ext_RM_dec}.info
            secure_command ${RM} -rf som/srv
            echo "Tarred rfm binary" >> ${DEBUG_FILE}  
            secure_command bzip2 --best ${TAR_PATH}/rfm3.tar
            echo "bzipped rfm binary" >> ${DEBUG_FILE}
        fi
     fi
     
     cd $RFM_PATH
     secure_command ${TAR} -cf ${TAR_PATH}/rfm0.tar som/rfm/rfm_scf_file.txt
     secure_command mkdir som/srv
     secure_command ${TAR} -tvf ${TAR_PATH}/rfm0.tar > som/srv/RM0M${ext}.${ext_RM_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/rfm0.tar som/srv/RM0M${ext}.${ext_RM_dec}.info
     secure_command ${RM} -rf som/srv
     echo "Tarred rfm binary" >> ${DEBUG_FILE}  
     secure_command bzip2 --best ${TAR_PATH}/rfm0.tar
     echo "bzipped rfm binary" >> ${DEBUG_FILE} 
     
     cd $RFM_PATH
     secure_command ${TAR} -cvf ${TAR_PATH}/rfm4.tar som/rfm/vegas/FRM-PROP_*.LAR som/rfm/vegas/vegas_rfm_sw_info.txt 
     secure_command mkdir som/srv
     secure_command ${TAR} -tvf ${TAR_PATH}/rfm4.tar > som/srv/RM4M${ext}.${ext_RM_dec}.info
     if test "$2" = "2"
     then
         cd $RFM_PATH/../
         secure_command ${TAR} -cf ${TAR_PATH}/rfm5.tar FRM-SW_060211*.LAR
         cd $RFM_PATH
         secure_command ${TAR} -tvf ${TAR_PATH}/rfm5.tar > som/srv/RM5M${ext}.${ext_RM_dec}.info
         secure_command ${TAR} -rf ${TAR_PATH}/rfm4.tar som/srv/RM4M${ext}.${ext_RM_dec}.info som/srv/RM5M${ext}.${ext_RM_dec}.info
         secure_command ${RM} -rf ${TAR_PATH}/rfm5.tar
         secure_command ${RM} -rf ../FRM-SW_060211*.LAR
     else
     secure_command ${TAR} -rf ${TAR_PATH}/rfm4.tar som/srv/RM4M${ext}.${ext_RM_dec}.info
     fi
     secure_command ${RM} -rf som/srv
     echo "Tarred rfm binary" >> ${DEBUG_FILE}  
     secure_command bzip2 --best ${TAR_PATH}/rfm4.tar
     echo "bzipped rfm binary" >> ${DEBUG_FILE}  

     cd $RFM_PATH
     if test "$2" = "1"
     then
        secure_command ${TAR} -cf ${TAR_PATH}/rfm5.tar ../FRM-SW_060211*.LAR
        secure_command mkdir som/srv
        secure_command ${TAR} -tvf ${TAR_PATH}/rfm5.tar > som/srv/RM5M${ext}.${ext_RM_dec}.info
        secure_command ${TAR} -rf ${TAR_PATH}/rfm5.tar som/srv/RM5M${ext}.${ext_RM_dec}.info
        secure_command ${RM} -rf som/srv
        secure_command ${RM} -rf ../FRM-SW_060211*.LAR
        echo "Tarred rfm binary" >> ${DEBUG_FILE}
        secure_command bzip2 --best ${TAR_PATH}/rfm5.tar
        echo "bzipped rfm binary" >> ${DEBUG_FILE}
     else
        if test "$2" = "2"
        then
            secure_command cp som/rfm/vegas/FRM-SW_060211*.LAR ${TAR_PATH}/.
            echo "Copied FRM_SW LAR file" >> ${DEBUG_FILE}
        else
            secure_command ${TAR} -cf ${TAR_PATH}/rfm5.tar som/rfm/vegas/FRM-SW_060211*.LAR
            secure_command mkdir som/srv
            secure_command ${TAR} -tvf ${TAR_PATH}/rfm5.tar > som/srv/RM5M${ext}.${ext_RM_dec}.info
            secure_command ${TAR} -rf ${TAR_PATH}/rfm5.tar som/srv/RM5M${ext}.${ext_RM_dec}.info
            secure_command ${RM} -rf som/srv
            echo "Tarred rfm binary" >> ${DEBUG_FILE}  
            secure_command bzip2 --best ${TAR_PATH}/rfm5.tar
            echo "bzipped rfm binary" >> ${DEBUG_FILE}
        fi
     fi

     #****************ESEA TARS**********************#
     #**********************************************#
     #**********************************************#
     #**********************************************#
        
#cd $ESEA_PATH
#    secure_command ${TAR} -cf ${TAR_PATH}/esea.tar som/esea/epswesea.ehx
#    secure_command mkdir som/srv
#    secure_command ${TAR} -tvf ${TAR_PATH}/esea.tar > som/srv/EM1_${ext}.${ext_EM_dec}.info
#    secure_command ${TAR} -rf ${TAR_PATH}/esea.tar som/srv/EM1_${ext}.${ext_EM_dec}.info
#    secure_command ${RM} -rf som/srv
#    echo "Tarred ESEA  binary" >> ${DEBUG_FILE}
#    secure_command bzip2 --best ${TAR_PATH}/esea.tar
#    echo "bzipped ESEA binary" >> ${DEBUG_FILE}  

     
     echo "Application file : Changed/Not Changed" > ${INPUT_FILE}
 

     if test "$1" = "1"
         then   
            
 
            echo " Making Build without any comparison">> \
             ${BUILD_PATH}/btspack_${pack_version}/btspack_log


             echo "SM1_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM2_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM3_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM4_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM5_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM6_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM7_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM8_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SM9_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SMA_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SO1_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SO2_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SO3_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "SO4_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "TM1_IR04.A5X :changed" >> ${INPUT_FILE}
			#echo "TM2_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "RM1_IR04.A5X :changed" >> ${INPUT_FILE}
			 echo "RM2_IR04.A5X :changed" >> ${INPUT_FILE}
			 echo "RM3_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "RM0_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "RM4_IR04.A5X :changed" >> ${INPUT_FILE}
             echo "RM5_IR04.A5X :changed" >> ${INPUT_FILE}

        
     fi

       
     if test "$1" = "2"
        then 

            echo "Making Build by comparing binaries with previous build">> \
                   ${BUILD_PATH}/btspack_${pack_version}/btspack_log

           binary_init 2 SM1 Sys_PL 
           binary_init 2 SM2 TAR_1 
           binary_init 2 SM3 TAR_2
           binary_init 2 SM4 TAR_3 
           binary_init 2 SM5 TAR_4
           binary_init 2 SM6 TAR_5 
           binary_init 2 SM7 TAR_6
           binary_init 2 SM8 TAR_7
           binary_init 2 SM9 TAR_8
           binary_init 2 SMA TAR_9
           binary_init 2 SO1 som1 
           binary_init 2 SO2 som2 
           binary_init 2 SO3 som3 
           binary_init 2 SO4 som4 
           binary_init 2 TM1 trx1
		   #binary_init 2 TM2 trx2
           binary_init 2 RM1 rfm1  
		   binary_init 2 RM2 rfm2   
		   binary_init 2 RM3 rfm3   
           binary_init 2 RM0 rfm0  
           binary_init 2 RM4 rfm4  
           binary_init 2 RM5 rfm5  

     fi 
 
         
    

     if test "$1" = "3"
       then 

          echo "Making Build by comparing binaries with baseline and then with previous build">> \
             ${BUILD_PATH}/btspack_${pack_version}/btspack_log

           binary_init 3 SM1 Sys_PL 
           binary_init 3 SM2 TAR_1 
           binary_init 3 SM3 TAR_2
           binary_init 3 SM4 TAR_3 
           binary_init 3 SM5 TAR_4
           binary_init 3 SM6 TAR_5 
           binary_init 3 SM7 TAR_6
           binary_init 3 SM8 TAR_7
           binary_init 3 SM9 TAR_8
           binary_init 3 SMA TAR_9
           binary_init 3 SO1 som1 
           binary_init 3 SO2 som2 
           binary_init 3 SO3 som3 
           binary_init 3 SO4 som4 
           binary_init 3 TM1 trx1
		   #binary_init 3 TM2 trx2
           binary_init 3 RM1 rfm1
		   binary_init 3 RM2 rfm2
		   binary_init 3 RM3 rfm3
           binary_init 3 RM0 rfm0
           binary_init 3 RM4 rfm4
           binary_init 3 RM5 rfm5
        
		   #binary_init 3 EM1 esea 
    fi


     #Create conf tar and copy it in tar_files directory */
     #****************conf data A50*****************#
     #**********************************************#
     #**********************************************#
     #**********************************************# 
                
     cd ${CONFIG_BUILD}
     echo "Config file generation for A50"
if [ "$PROC" == Linux ]
     then
     secure_command mkdir $CONF_PATH/som/srv
     secure_command mv me/A50/ep_som_cfg_file $CONF_PATH/som/srv/.
     else
     secure_command ./config_file_builder A50
     secure_command mkdir $CONF_PATH/som/srv
     secure_command mv ep_som_cfg_file $CONF_PATH/som/srv/.
    fi	
     cd $CONF_PATH
     secure_command ${TAR} -cf ${TAR_PATH}/btsconf_A50.tar som/srv/*
     secure_command ${TAR} -tvf ${TAR_PATH}/btsconf_A50.tar >\
               som/srv/CFGM${ext}.${ext_BTS_CFG_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/btsconf_A50.tar  \
               som/srv/CFGM${ext}.${ext_BTS_CFG_dec}.info
     echo "Tarred config file for A50" >> ${DEBUG_FILE}  
     secure_command ${RM} -rf $CONF_PATH/som/srv
     secure_command bzip2 --best ${TAR_PATH}/btsconf_A50.tar
     echo "bzipped config file for A50" >> ${DEBUG_FILE}  


     #Create conf tar and copy it in tar_files directory#
     #****************conf data A53*****************#
     #**********************************************#
     #**********************************************#
     #**********************************************#     
     
     cd ${CONFIG_BUILD}
     echo "Config file generation for A53"
if [ "$PROC" == Linux ]
then
     secure_command mkdir $CONF_PATH/som/srv
     secure_command mv me/A53/ep_som_cfg_file $CONF_PATH/som/srv/.
else
     secure_command ./config_file_builder A53
     secure_command mkdir $CONF_PATH/som/srv
     secure_command mv ep_som_cfg_file $CONF_PATH/som/srv/.
fi
     cd $CONF_PATH
     secure_command ${TAR} -cf ${TAR_PATH}/btsconf_A53.tar som/srv/*
     secure_command ${TAR} -tvf ${TAR_PATH}/btsconf_A53.tar > \
            som/srv/CFGM${ext_3}.${ext_BTS_CFG_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/btsconf_A53.tar \
              som/srv/CFGM${ext_3}.${ext_BTS_CFG_dec}.info
     secure_command ${RM} -rf $CONF_PATH/som/srv
     echo "Tarred config file for A53" >> ${DEBUG_FILE}  
     secure_command bzip2 --best ${TAR_PATH}/btsconf_A53.tar
                                                                    
     echo "Bzipped config file for A53" >> ${DEBUG_FILE}  
  
     cd ${BUILD_PATH}
     
     del_func tmp
     del_func ${ERROR_FILE}

     cd ${TAR_PATH}/
     

     af_file_create SM1 ${ext_SM1_SM5_dec} 0 0 ${syspl_version} Sys_PL.tar
     af_file_create SM2 ${ext_SM1_SM5_dec} 0 1 ${trs_version_1} TAR_1.tar 
     af_file_create SM3 ${ext_SM1_SM5_dec} 0 2 ${trs_version_2} TAR_2.tar 
     af_file_create SM4 ${ext_SM1_SM5_dec} 0 3 ${trs_version_3} TAR_3.tar 
     af_file_create SM5 ${ext_SM1_SM5_dec} 0 4 ${trs_version_4} TAR_4.tar
     af_file_create SM6 ${ext_SM1_SM5_dec} 0 5 ${trs_version_5} TAR_5.tar 
     af_file_create SM7 ${ext_SM1_SM5_dec} 0 6 ${trs_version_6} TAR_6.tar
     af_file_create SO1 ${ext_SO1_SO2_dec} 0 7 ${som_version_1} som1.tar
     af_file_create SO2 ${ext_SO1_SO2_dec} 0 8 ${som_version_2} som2.tar 
     af_file_create SO3 ${ext_SO1_SO2_dec} 0 9 ${som_version_3} som3.tar
     af_file_create SO4 ${ext_SO1_SO2_dec} 0 10 ${som_version_4} som4.tar
     af_file_create TM1 ${ext_TM_dec} 1 11 ${trx_version_1} trx1.tar.bz2
     #af_file_create TM2 ${ext_TM_dec} 1 15 ${trx_version_2} trx2.tar
     af_file_create RM1 ${ext_RM_dec} 2 12 ${rfm_version} rfm1.tar.bz2 
     af_file_create RM2 ${ext_RM_dec} 2 13 ${rfm_version_1} rfm2.tar.bz2 
     #af_file_create RM3 ${ext_RM_dec} 2 14 ${rfm_version_2} rfm3.tar.bz2
     #af_file_create EM1 ${ext_EM_dec} 3 13 ${esea_version} esea.tar.bz2 
     af_file_create SM8 ${ext_SM1_SM5_dec} 0 15 ${trs_version_7} TAR_7.tar
     if test "$2" = "2"
     then
     af_file_create RM3 ${ext_RM_dec} 2 16 ${rfm_version_2} FRM-SW_040211*.LAR
     else
     af_file_create RM3 ${ext_RM_dec} 2 16 ${rfm_version_2} rfm3.tar.bz2
     fi
	 af_file_create SM9 ${ext_SM1_SM5_dec} 0 17 ${trs_version_8} TAR_8.tar
     af_file_create SMA ${ext_SM1_SM5_dec} 0 18 ${trs_version_9} TAR_9.tar
     af_file_create RM0 ${ext_RM_dec} 2 19 ${rfm_version_3} rfm0.tar.bz2 
     af_file_create RM4 ${ext_RM_dec} 2 20 ${rfm_version_4} rfm4.tar.bz2 
     if test "$2" = "2"
     then
     af_file_create RM5 ${ext_RM_dec} 2 21 ${rfm_version_5} FRM-SW_060211*.LAR
     else
     af_file_create RM5 ${ext_RM_dec} 2 21 ${rfm_version_5} rfm5.tar.bz2
     fi
          

    secure_command  ../${AF_BUILD} -r"${ext}"${ext_BTS_CFG_dec} -n0 -e14 -V${btsconf_version}\
            btsconf_A50.tar.bz2 >>  \
			${BUILD_PATH}/btspack_${pack_version}/btspack_log

     #do not change the ordering of RM1/RM2/RM3
     secure_command ../${MF_BUILD} ${pack_version} "${ext}"${ext_BTS_CFG_dec} SM1* \
     SM2* SM3* SM4* \
     SM5* SM6* SM7* \
     SM8* SM9* SMA* SO1* \
     SO2* SO3* SO4* \
     TM1* RM1* \
     RM2* RM3* RM0*\
     RM4* RM5* \
     CFGM${ext}.${ext_BTS_CFG_dec}  >> \
     ${BUILD_PATH}/btspack_${pack_version}/btspack_log

     secure_command cp SM1* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM2* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM3* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM4* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM5* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM6* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM7* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM8* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SM9* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SMA* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SO1* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SO2* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SO3* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp SO4* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp TM1* ${BUILD_PATH}/btspack_${pack_version}/A50/.
	 #secure_command cp TM2* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM1* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM2* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM3* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM0* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM4* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp RM5* ${BUILD_PATH}/btspack_${pack_version}/A50/.
	 #secure_command cp EM1* ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp CFGM${ext}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command cp BTSM${ext}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version}/A50/.
     secure_command ${RM} -f *.A50
     
     


     echo "Successfully created btspack_${pack_version} for A50"

     #do not change the ordering of RM1/RM2/RM3 
     secure_command ../${AF_BUILD} -r"${ext_3}"${ext_BTS_CFG_dec} -n0 -e14 -V${btsconf_version_3}\
             btsconf_A53.tar.bz2 >>  \
			 ${BUILD_PATH}/btspack_${pack_version}/btspack_log
     secure_command ../${MF_BUILD} ${pack_version_3} "${ext_3}"${ext_BTS_CFG_dec} SM1* \
                   SM2* SM3* \
                   SM4* SM5* \
                   SM6* SM7* SM8* SM9* \
                   SMA* SO1* SO2* SO3* SO4* \
                   TM1* RM1* \
                   RM2* RM3* RM0*\
                   RM4* RM5* \
                   CFGM${ext_3}.${ext_BTS_CFG_dec}  >> \
                   ${BUILD_PATH}/btspack_${pack_version}/btspack_log
    
     secure_command cp SM1* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM2* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM3* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM4* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM5* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM6* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM7* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM8* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SM9* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SMA* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SO1* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SO2* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SO3* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp SO4* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp TM1* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
	#secure_command cp TM2* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM1* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM2* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM3* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM0* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM4* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp RM5* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
	#secure_command cp EM1* ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp CFGM${ext_3}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     secure_command cp BTSM${ext_3}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
     
     secure_command ${RM} -f *.A53
     echo "Successfully created btspack_${pack_version_3} for A53"

     
     #Remove the temporary created "tar_files" folder
     cd ${TAR_PATH}/
     secure_command ${RM} -f *

     cd ${BUILD_PATH}
     secure_command ${RM} -rf ${TAR_PATH}

     #Remove the temporary created "srv" folder
     cd ${SRV_PATH}/srv
     secure_command ${RM} -f *

     cd ${SRV_PATH}
     secure_command ${RM} -rf srv/

     #remove the directories created for the new flash file structure
     secure_command ${RM} -rf ${BUILD_PATH}/som
     
     chmod 755  ${BUILD_PATH}/btspack_${pack_version}
     chmod 755  ${BUILD_PATH}/btspack_${pack_version_3}
    



echo "Exit trace, Function:create_build" >> ${DEBUG_FILE}   
opt1="4" 
}







who am i > ${LOG_FILE}
#secure_command  cp debug.txt /priya/ 2>/dev/null
while [ /bin/true ]  
  do
#      echo "Enter 1 to make build forcefully"
 #     echo "Enter 2 to make build by using comparison(with IB build)"
  #    echo "Enter 3 to make build by using comparison(LRB, IB build)"
   #   echo "Enter 4 to exit application" 
    #  read option
      
 #     echo "User Selected option : $opt1" >>${LOG_FILE}

      if test "$opt1" = "1" || test "$opt1" = "2" || test "$opt1" = "3"
      then
        
        while [ /bin/true ]  
        do
#            echo "Enter 1 to make flash optimized build"
 #           echo "Enter 2 to make flash and ram optimized build"
  #          echo "Enter 3 for non flash optimization"
   #         echo "Enter 4 to exit application"
    #        read option2
            
#            echo "User Selected flash optimization option : $opt2" >>${LOG_FILE} 
#            case "$opt2" in
 #               1) echo "creating flash optimized build";;
  #              2) echo "creating flash and ram optimized build";;
   #             3) echo "creating non flash optimized build";;
    #            4) exit;;
     #           *) echo "Wrong option Please enter option again" ;;
      #      esac
            
            if test "$opt2" = "1" || test "$opt2" = "2" || test "$opt2" = "3"
            then
                case "$opt1" in
                1) create_build  1  $opt2;;
                2) create_build  2  $opt2;;
                3) create_build  3  $opt2;;
                esac
                break;
            fi
        done
      else
        if test "$opt1" = "4"
        then
            exit
        else
            echo "Wrong option Please enter option again"
        fi
      fi
  done 

