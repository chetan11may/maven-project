
# ************************************************************************************                       *********
# File      : size_check.sh
#
# Purpose   : Checking size of fpwork and if its less then 49 GB send mail
#
# Remark    : Syntax: size_check.sh
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# ************************************************************************************                        *********



#!/bin/bash
rm -rf alert.txt

size_limit=50

#For /var/fpwork mounts
        for r in bhling32 bhling23
        do
                fpwork_size=$((`ssh gsmbtsscm@$r "df  /var/fpwork" |sed -n '3p'|tr -s ' '|cut -d ' ' -f4` / 1048576))  #to get free space in GB of linsee mounts
                echo "$fpwork_size GB is available in mount /var/fpwork on $r "
                r_fpwork_size=`echo $fpwork_size |cut -d '.' -f1`   #removing off decimal place
                if (( $r_fpwork_size < $size_limit )) ; then 
			echo "$r_fpwork_size GB of space is left in /var/fpwork on $r which is less than $size_limit GB <br>" >> alert.txt 
                fi
        done
	if [ ! -f alert.txt ] ;
	then
		echo -e "Space is more then $size_limit GB !! exiting"	
		exit 1
	fi


