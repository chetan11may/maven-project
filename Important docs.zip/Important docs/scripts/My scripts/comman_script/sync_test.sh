# *********************************************************************************************
# File      : sync_test.sh
#
# Purpose   : sync_test.sh for checking the revision number of bhscme.inside.nsn and svne1.access.nsn should be same
#
# Remark    : Syntax: sync_test.sh
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# *********************************************************************************************



#!/bin/bash
rm -rf out_of_sync.txt

var="/isource/svnroot/BSS_BTS_SW/EX" 


for i in $var;
   do
	echo $i
        SLAVE_REV=`svn info https://bhscme.inside.nsn.com$i | grep -i ^revision | cut -f2 -d ' '`
	echo " Slave server rev: $SLAVE_REV"

        MASTER_REV=`svn info https://svne1.access.nsn.com$i | grep -i ^revision | cut -f2 -d ' '`
	echo "Master server rev: $MASTER_REV"

        # check if the revisions are not equal
        if [ $SLAVE_REV != $MASTER_REV ]
           then
		
		echo "MASTER_REV ($MASTER_REV) and SLAVE_REV ($SLAVE_REV) are not same!!!!!!CRITICAL $i is out of sync"
                echo " SVN details  <br>  MASTER_SVN: https://svne1.access.nsn.com$i ($MASTER_REV) <br> SLAVE_SVN: https://bhscme.inside.nsn.com$i ($SLAVE_REV) <br> Master and Slave revision are not same!!!! out of sync  <br>" >> out_of_sync.txt
	else
		echo "OK SVN servers $* are in sync"
                exit 1
	fi
   done



