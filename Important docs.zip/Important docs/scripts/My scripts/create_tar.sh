#!/bin/bash
if [ $# != 4 ]
   then
        echo "USAGE:- $0 Feature $1 platfrom $2 Path $3 bldtype
        eg : $0 <RG302087> <me/ep>  </var/fpwork_bkp1/workspace_scmci/folderpath>> <reg>"
        exit 1
fi
export feature=$1
export build_plat=$2
export tarpath=$3
export bldtype=$4

NOW=$(date +"%m%d%Y")
source config.txt
FILE="$build_tag"_"$build_plat"_"$bldtype".tar
cd $tarpath
tar -cvf $FILE btspack_05.20-00 btspack_05.20-03
echo "Backing up data to $FILE file, please wait..."
