#! /usr/bin/perl
# ***************************************************************************************
# File      : send_mail.pl
#
# Purpose   : sends mails if there is less space available at /var/fpwork
#
# Remark    : Syntax: perl send_mail_new.pl
#
# Author    : Murali
#
# Copyright (C) NSN 2013
#
# ***************************************************************************************

$size=$ARGV[1];
print "$last_name";

if ( $ARGV[0] eq bhling32 )
{

$message= 'space is available in /var/fpwork on bhling32 , remove the unused files and folder' ;
$sub= 'less space available in /var/fpwork on bhling32';

}

if ( $ARGV[0] eq bhling23 )
{

$message= 'space is available in /var/fpwork on bhling23 , remove the unused files and folder' ;
$sub= 'less space available in /var/fpwork on bhling23';

}


use lib "packages/libnet-1.22/libnet-1.22/Net";  # use the parent directory
use lib "packages/MIME-Lite-3.028/lib";
use lib "packages/Email-Date-Format-1.002/lib";
use MIME::Lite;
use Net::SMTP;
open(DATA, "<props.properties");
 $from="nsn.btsman\@nsn.com";
 $to="chetan.1.anand\@nsn.com";

while(<DATA>)
{

 if ($_ =~/App_sack/)
        {
                $app_sack_line = $_;
                ($mcrnc,$app_sack) = split(/=/,$app_sack_line);
                chomp($app_sack);
                #print "mcRNC_PF_sack-$mcRNC_PF_sack\n";
        }
 if ($_ =~/BUILD_TAG_MCRNC/)
        {
                $BUILD_TAG_MCRNC_line = $_;
                ($mcrnc,$build_tag) = split(/=/,$BUILD_TAG_MCRNC_line);
                chomp($build_tag);
                #print "mcRNC_PF_sack-$mcRNC_PF_sack\n";
        }
 if ($_ =~/IL/)
        {
                $il_line = $_;
                ($mcrnc,$il) = split(/=/,$il_line);
                chomp($il);
                #print "mcRNC_PF_sack-$mcRNC_PF_sack\n";
        }
 if ($_ =~/FP/)
        {
                $FP_line = $_;
                ($mcrnc,$fp) = split(/=/,$FP_line);
                chomp($fp);
                #print "mcRNC_PF_sack-$mcRNC_PF_sack\n";
        }

 if ($_ =~/PF_SACK/)
        {
                $PF_SACK_line = $_;
                ($mcrnc,$pf_sack) = split(/=/,$PF_SACK_line);
                chomp($pf_sack);
                #print "mcRNC_PF_sack-$mcRNC_PF_sack\n";
        }


}

#### Mail Host
  $mail_host = 'mail.emea.nsn-intra.net';
### Subject
  $subject = "$sub ";
 ### Create the multipart container
                $msg = MIME::Lite->new (
                From => $from,
                To => $to,
                Subject => $subject,
                Type =>'multipart/mixed'
                ) or die "Error creating multipart container: $!\n";
                ### Add the text message part


### Message Body
   $msg->attach(
                        Type     =>'HTML',
                        Data     =>"<HTML><BODY><font color='blue' face='Cambria' size='2'>

Hi,
<br><br>
<font color='red' face='Cambria' size='2.50'>
Only $size GB $message
</font>

<br>

</font>
<font color='blue' face='Cambria' size='2.50'>

<br>
Regards<br>
Btsman
</font>
</BODY>
</HTML>

"
);

## To set high importance
#$msg->add('X-MSMail-Priority' => 'High');

 ## Send the Message
                                MIME::Lite->send('smtp', $mail_host, Timeout=>60);
                                $msg->send;
                                print "Message Sent\n";


