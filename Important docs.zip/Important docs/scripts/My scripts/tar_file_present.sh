# *********************************************************************************************
# File      : tar_file_present.sh
#
# Purpose   : Checking both the tar ep and me is present if not wait untill we have !!
#
# Remark    : Syntax: ./tar_file_present.sh <build_plat_ep> <build_plat_me>
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# *********************************************************************************************



#!/bin/bash

if [ $# != 2 ]
   then
        echo "USAGE:- $0  <build_plat_ep> <build_plat_me>
        eg : $0 ep me reg"
        exit 1
fi

plat_ep=$1
plat_me=$2

source config.txt

while true

do
ep_tar=`ls -lrth $BUILD_FOLDER_PATH/"$plat_ep"_"$build_tag"/sys/som/build | tr -s " " | grep "$build_tag"_"$plat_ep".tar | cut -d" " -f9`
me_tar=`ls -lrth $BUILD_FOLDER_PATH/"$plat_me"_"$build_tag"/sys/som/build | tr -s " " | grep "$build_tag"_"$plat_me".tar | cut -d" " -f9`



if [ "$ep_tar" == "$build_tag"_"$plat_ep".tar ] && [ "$me_tar" == "$build_tag"_"$plat_me".tar ];
        then
        echo -e "both tar file are present!!! Continuing!!!!"
        break

elif [ "$ep_tar" != "$build_tag"_"$plat_ep".tar ];
	then
	echo -e "$ep_tar tar file are not present, please wait !!!"

else  [ "$me_tar" != "$build_tag"_"$plat_me".tar ];
	
	echo -e "$me_tar tar file are not present, please wait !!!!"
        sleep 30

fi
done
