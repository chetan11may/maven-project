# ***************************************************************************************
# File      : check_tar_file.sh
#
# Purpose   : Checking the tar file is exist or not proper and send the mail
#
# Remark    : Syntax: ./check_tar_file.sh <build_plat>
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# ***************************************************************************************

#!/bin/sh


if [ $# != 1 ]
   then
        echo "USAGE:- $0  <build_plat> $1
        eg : $0 ep "
        exit 1
fi

source config.txt

build_plat="$1"
bldtype=$2

File=`ls -lrt $BUILD_FOLDER_PATH/"$build_plat"_"$build_tag"/sys/som/build | tr -s " " | grep tar | cut -d' ' -f9`

size="${build_plat}_pack_size"
pack_size="$[$size]"
echo "file name is $File"
echo "threshold value of tar size is $pack_size"

cd $BUILD_FOLDER_PATH/"$build_plat"_"$build_tag"/sys/som/build
pwd

if [ -f "$File" ]
then
	echo "File is $File"
        size_check=`ls -lrt $BUILD_FOLDER_PATH/"$build_plat"_"$build_tag"/sys/som/build | tr -s " " | grep tar | cut -d' ' -f5`
	echo -e " Tar file exist ($File)  Size of the Tar file is :$size_check byte"
        
	if [ "$size_check" -ge "$pack_size" ] ;
                then
	        echo -e "$File  size is proper"
        else
                echo -e "$File size($size_check) should be more then the $pack_size!!!!!!(send mail)Exiting"
		cd $SCRIPT_PATH
                perl send_mail.pl file_not_proper $File
            #    exit 1
        fi
else
        echo -e "Error :: Tar file isn't exist, please check!!!!!!!!Exiting"
	cd $SCRIPT_PATH
        perl send_mail.pl file_doesnt_exist $File
 #       exit 1
fi

