# ***************************************************************************************
# File      : baseno_monitoring.sh
#
# Purpose   : Checking the base number of the package
#
# Remark    : Syntax: ./baseno_monitoring.sh <build_plat>
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# ***************************************************************************************


#!/bin/sh

if [ $# != 1 ]
   then
        echo "USAGE:- $0  <build_plat> $1
        eg : $0 ep "
        exit 1
fi

#source config.txt
build_plat="$1"

printf -v result "%x" "$baseno"

z=`echo $result | sed 's/.*/\U&/'`

echo -e "$z" is the hexadecimal of $basenum basenum which is available in config.txt

folder=`echo "$BUILD_FOLDER_PATH/"$build_plat"_"$build_tag"/sys/som/build"`

echo "$folder" is the current working directory

for i in btspack_05.20-00/A50  btspack_05.20-03/A53
	do
	cd $folder/"$i"
	for j in BTS CFG
		do
		present_dir=`pwd`
		echo "the current directory is $present_dir"
		file_name=`ls -lrt | tr -s " " | grep $j | cut -d" " -f9`
		echo package name: $file_name
		d=`echo $file_name | cut -d"." -f2 | cut -c1,2`
		echo "$d is the hexadecimal of the baseno of the $file_name of the "$build_plat" build"
		if [ "$z" == "$d" ]
		then
			echo " "$build_plat" build having the correct base number"
		else 
			echo "Basenum of config.txt "$z" and "$build_plat" build packages "$d" are not same for the package "$file_name" !!!!!! exiting"
			exit 1
		fi
	done 

done

