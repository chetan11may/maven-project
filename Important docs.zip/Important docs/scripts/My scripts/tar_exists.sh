# ************************************************************************************                       *********
# File      : tar_file_present.sh
#
# Purpose   : Checking both the tar ep and me is present if not wait untill we have !!
#
# Remark    : Syntax: tar_file_present.sh
#
# Author    : Chetan Anand
#
# Copyright (C) NSN 2014
#
# ************************************************************************************                        *********



#!/bin/bash

source config.txt
ep_tar=`ls -lrth  $BUILD_FOLDER_PATH/ep_$build_tag/sys/som/build | grep $build_tag_ep.tar | cut -d" " -f10`
me_tar=`ls -lrth $BUILD_FOLDER_PATH/me_$build_tag/sys/som/build | grep $build_tag_me.tar | cut -d" " -f10`

echo -e "$ep_tar"
echo -e "$me_tar"


while true

do

if [ "$ep_tar" == "$build_tag"_ep.tar ] && [ "$me_tar" == "$build_tag"_me.tar ];
        then
        echo -e "tar file are present"
        exit 2
else
        echo -e "tar file are not present wait !!!!"
        sleep 30
fi
done

