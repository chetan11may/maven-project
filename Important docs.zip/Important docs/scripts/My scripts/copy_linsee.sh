# ***************************************************************************************
# File      : copy_trunk_linsee.sh
#
# Purpose   : Copy to linsee code modified for RSM
#
# Remark    : Syntax: ./copy_trunk_linsee.sh <mode>
#
# Author    : 
#
# Copyright (C) NSN 2011
#
# ***************************************************************************************

#To set the build mode

if [ $# != 1 ]
   then
        echo "USAGE:- $0 Feature
        eg : $0 <RG302087>"
        exit 1
fi
#export the build mode
export feat=$1
export build_platfrom=$2
export FILEPATH=$3
#V1="x86_64"
V2="x86_64_fbsa"

#Source Config txt file
source config.txt
source oldtag.txt
export BUID_TAG=$build_tag
export old_tag=$OLD_BUILD_TAG
initial()
  {
	echo "creating the folder $copy_location/$feat/$BUID_TAG"
	mkdir -p $copy_location/$feat/$BUID_TAG
  }


md5sum_size()
   {
	echo "preparing md5sum and size for $BUILD_TAG"
	cd $copy_aricent_location/$BUILD_TAG
	find . -type f -exec md5sum  {} \; > md5sum.txt
	ls -lR > size.txt
   }

svn_info()
{
echo "preparing svn info for $BUID_TAG"
cd $SCRIPT_PATH/HTML
mv -vf dif_chgd_dtls.html "$BUID_TAG"_"$OLD_BUILD_TAG"_changes.html
cp -vf "$build_tag"_"$old_tag"_changes.html  $copy_location/$feat/$BUID_TAG
cp -vf "$build_tag"_"$old_tag"_changes.html $html_location

}

copy()
{
#mkdir -p $copy_aricent_location/$BUILD_TAG
cd $copy_location/$featname/$build_platfrom
cp -rvf /$FILEPATH/*.tar .
}

copytrunk()
{
#copying the regular build
cd $copy_location/TRUNK/$BUID_TAG
#for ME
cp -rvf $BUILD_FOLDER_PATH/me_"$build_tag"_reg/sys/som/build/*.tar .
#for EP
cp -rvf $BUILD_FOLDER_PATH/ep_"$build_tag"_reg/sys/som/build/*.tar .
#copying the customer build
cd $copy_location/TRUNK/$BUID_TAG
#for ME
cp -rvf $BUILD_FOLDER_PATH/me_"$build_tag"_cust/sys/som/build/*.tar .
#for EP
cp -rvf $BUILD_FOLDER_PATH/ep_"$build_tag"_cust/sys/som/build/*.tar .
}

copyem()
{
cd $copy_location/TRUNK/$BUID_TAG
cp -rvf $EM_PATH/"$EM_BUILD".zip .
cp -rvf $SCRIPT_PATH/readme.txt .
}
copytest()
{
#copying the Regular builds
cd $BUILD_FOLDER_PATH/me_"$build_tag"_reg/sys/som/build
scp *.tar root@10.43.13.96:/BTS_BUILDS
cd $BUILD_FOLDER_PATH/ep_"$build_tag"_reg/sys/som/build
scp *.tar root@10.43.13.96:/BTS_BUILDS
#copying the customer builds
cd $BUILD_FOLDER_PATH/me_"$build_tag"_cust/sys/som/build
scp *.tar root@10.43.13.96:/BTS_BUILDS
cd $BUILD_FOLDER_PATH/ep_"$build_tag"_cust/sys/som/build
scp *.tar root@10.43.13.96:/BTS_BUILDS
}

#call the functions
#copy

initial
copytrunk
copyem
copytrunk
svn_info
