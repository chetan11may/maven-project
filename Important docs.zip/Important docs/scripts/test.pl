#!/usr/bin/perl -w
use strict;
#getting latest revision
my $numArgs = shift @ARGV;
print $numArgs,"\n";
my $url = " https://bhscme.inside.nsn.com/isource/svnroot/BSS_BTS_SW/common";
my @svn_ls=`svn ls  https://bhscme.inside.nsn.com/isource/svnroot/BSS_BTS_SW/common/em/tags/GSM16_TRUNK_EM/$numArgs`;
print @svn_ls;
open(FILE,">D:\\userdata\\cheanand\\Desktop\\tag.txt") or print "unable to create file $!";

foreach (@svn_ls)
{
 chop $_;
 chop $_;
	my @rev=`svn info https://bhscme.inside.nsn.com/isource/svnroot/BSS_BTS_SW/common/em/tags/GSM16_TRUNK_EM/$numArgs/$_`;
	print "$_ $rev[7]";
	my @revision=split(":",$rev[7]);
	print $revision[1];
	print FILE "$_ $revision[1]";
	}
	
close (FILE);
open(FILE1,">D:\\userdata\\cheanand\\Desktop\\trunk.txt") or print "unable to create file $!";
	my @trunk_cl =`svn info $url/cl/branches/CL_INT_OT3`;
	print "cl $trunk_cl[7]";
	my @revision_cl=split(":",$trunk_cl[7]);
	print $revision_cl[1];
	print FILE1 "cl $revision_cl[1]";
	
	my @trunk_em =`svn info $url/em/trunk`;
	print "em $trunk_em[7]";
	my @revision_em=split(":",$trunk_em[7]);
	print $revision_em[1];
	print FILE1 "em $revision_em[1]";
	
close (FILE1);
use Text::Diff;
my $diffs = diff 'D:\\userdata\\cheanand\\Desktop\\trunk.txt' => 'D:\\userdata\\cheanand\\Desktop\\tag.txt';

print $diffs;

 if ($diffs) {
        print "diff are present!!!!so continue "
    } else {
        print " No diff are present";
		exit 1
    }


