#!/bin/bash

# ***************************************************************************************
# File      : start_tag.sh
#
# Purpose   : Trigger scripts for creating tag and check-out modified for RSM
#
# Remark    : Syntax: start_tag.sh <package name> <variant>
#
# Author    : Sandhya C. A.
#
# Copyright (C) NSN 2011
#
# ***************************************************************************************
#usage
if [ $# != 6 ]
   then
     {
	echo -e "\nPlease give all the needed parameters"
    	echo -e "Usage: $0 [-b <BUILD TYPE> ] [-t <BUILD TAG>] [-u <bng]"
	#changed for RSM 
    	echo -e "  e.g: \$ $0 -b <trunk/R_QR.1.0_0.1> -t <R_QR.1.0.0.1> -u <bng/esp>\n"
	exit 1
     }
fi

while getopts b:t:u: var
do	
    case "$var" in
	b)	
	   build_type=$OPTARG; echo $build_type
		
	   case $build_type in
		trunk)
			#changed the var2 for rsm-main
			export var1=$build_type; var2=$build_type
			echo $var1 $var2
			;;
#to be changed
		R_QR.1.0.0.74) 
			export var1='branches';var2=$build_type
			echo $var1 $var2
			;;
        	RG302087_INT)
                        export var1='branches';var2=$build_type
                        echo $var1 $var2
                        ;;
		*)
                        echo "Please enter a valid value for build type [-b option]"
                        exit 1
                        ;;
	   esac
           ;;
	 t)
           build_tag=$OPTARG; echo $build_tag;;

       	 u)
                server=$OPTARG; echo $server
		export var3=$server
		;;
	[?])	
	   echo "Please enter a valid option";;
    esac
done

#added by santhosh creating props.properties file which is used By SWBT. props.properties file
#echo "BUILD_TA=$build_type" | tee -a props.properties

rm -f error_component_list.txt

#create the externals
externals()
   {
	rm -f log_script.txt  log.txt info_url.txt

        echo "Starting svn_co_url.pl"
        ./svn_co_url.pl $var1 $var2 $var3

   }

#create the tag 
#removed the "_tst" from the script name 
tag()
   {
        echo "Creating tag"
        ./create_tag.sh -b $var2 -u $var3
	
   }

#externals
tag
