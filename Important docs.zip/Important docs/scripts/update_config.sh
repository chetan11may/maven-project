# ***************************************************************************************
# File      : update_config.sh
#
# Purpose   : updating config file for buildtag RSM
#
# Remark    : Syntax: ./update_config.sh <buildtag> <buildtype>
#
# Author    : Suma K.
#
# Copyright (C) NSN 2011
#
# ***************************************************************************************
#usage
if [ $# != 6 ]
   then
     {
        echo -e "\nPlease give all the needed parameters"
        echo -e "Usage: $0 [-b <BUILD TYPE> ] [-t <BUILD TAG>] [-p <SCRIPT PATH>]"
        #changed for RSM
        echo -e "  e.g: \$ $0 -b <trunk/R_QR.1.0_0.1> -t <R_QR.1.0.0.1> -p </scripts/>\n"
        exit 1
     }
fi
#Get options
while getopts b:t:p: var
do
    case "$var" in
        b)
           buildtype=$OPTARG; echo $buildtype
  	   ;;

        t)
           buildtag=$OPTARG; echo $buildtag;;
	p)
           scriptpath=$OPTARG; echo $scriptpath;;

	[?])
           echo "Please enter a valid option";;
    esac
done
source config.txt

#Get the old value from the config.txt
old_build_tag=`cat $scriptpath/config.txt | grep build_tag | cut -d '=' -f2`
echo "old build tag is: $old_build_tag"
echo "new build tag is:$buildtag"
#update the config.txt from old value to new value
echo sed -i -e "s/$old_build_tag/$buildtag/g" $scriptpath/config.txt
sed -i -e "s/$old_build_tag/$buildtag/g" $scriptpath/config.txt


#Get the old value from the config.txt
old_build_type=`cat $scriptpath/config.txt | grep build_type | cut -d '=' -f2`
echo "old build tag is: $old_build_type"
echo "new build tag is:$buildtype"
#update the config.txt from old value to new value
echo sed -i -e "s/$old_build_type/$buildtype/g" $scriptpath/config.txt
sed -i -e "s/$old_build_type/$buildtype/g" $scriptpath/config.txt

#Creating par.txt for automated  build email
#source config.txt
#echo "build_tag=$build_tag" | tee  par.txt
#echo "FP=$FP" | tee -a par.txt


