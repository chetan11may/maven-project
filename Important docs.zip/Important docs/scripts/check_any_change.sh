# ***************************************************************************************
# File      : checkchange.sh
#
# Purpose   : Check the changes in the tag before tag creation
#
# Remark    : Syntax: ./check_any_change.sh  <build_type> <BUILD_TAG> <BUILD_TAG_OLD>
#
# Author    :
#
# Copyright (C) NSN 2011
#
# ***************************************************************************************

#Usage

if [ $# != 3 ]
  then
        echo -e "\nUSAGE:-     ./check_any_change.sh  <build_type> <BUILD_TAG> <BUILD_TAG_OLD> \n"
                exit 1
  else
        export BUILD_TYPE=$1
        export BUILD_TAG=$2
        export BUILD_TAG_OLD=$3
fi
source config.txt
rm -f ans_final.txt log.txt log_script.txt par1.txt
JOIN=`echo $BUILD_TAG"_"$BUILD_TAG_OLD`

#./get_freeze_info.sh $BUILD_TYPE  $BUILD_TAG bng
 cd HTML
./get_freeze_info.sh $BUILD_TYPE  $BUILD_TAG_OLD bng
cp -rvf $BUILD_TAG_OLD.txt ../

cd $SCRIPT_PATH

cat $BUILD_TAG_OLD.txt | cut -d ' ' -f 1-2 > a2.txt
echo "Finding freeze info for $BUILD_TAG...."

if [ "$build_type" == "trunk" ]
   then
        var2="rsm-main"
      ./svn_co_url.pl  $build_type  $var2 bng
else
     ./svn_co_url.pl  branches $build_type  bng

fi

sed '/^$/d' log_script.txt > tag_new.txt #to remove blank lines from tag.txt
mv -f tag_new.txt tag_name.txt
rm -f "$BUILD_TAG"_test.txt

while read line    #reading line by line of tag.txt
 do
        name=`echo $line | cut -d ' ' -f1`      #component name
        revision=`echo $line | cut -d ' ' -f2`  #Revision no in -r400 format
        rev=`echo $revision | cut -d 'r' -f2`   #Revision no alone (400)

        url=`echo $line | cut -d ' ' -f3`       #svn url

        last_changed_rev=`svn info $BHSCME_URL/$url@$rev | grep "Last Changed Rev" | cut -d ' ' -f 4`
                                                                              #last changed rev

        #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
        echo -e "$name -r$last_changed_rev $url" >> "$BUILD_TAG"_test.txt

 done < tag_name.txt
cat  "$BUILD_TAG"_test.txt | cut -d ' ' -f 1-2 > a1.txt
diff -r a2.txt  a1.txt |cut -d ' '  -f2 | sort -u | grep -v ^[0-9] | grep -v ^-|grep -v product > ans_diff_$JOIN.txt

_file="ans_diff_$JOIN.txt"
[ $# -eq 0 ] && { echo "Usage: $0 filename"; exit 1; }
[ ! -f "$_file" ] && { echo "Error: $0 file not found."; exit 2; }

if [ -s "$_file" ]
then
        echo "$_file has some data."
        # do something as file has data
else
        echo "$_file is empty, There are currently no changes in the components."
       rm -rf a2.txt a1.txt ans_diff_$JOIN.txt  tag_new.txt log_script.txt tag_name.txt log_script.txt log.txt
	svn co $BHSCME_URL/isource/svnroot/SS_QRProduct/$build_type/product tmp_$build_type
        cd tmp_$build_type/build
                pwd
		#Get the MKCS_RISLABEL value from the svnenv.sh file
        no2=1
        no1=`cat svnenv.sh  | grep "export MKCS_RISLABEL" | head -1 | cut -d '"' -f2 | cut -d '.' -f5`

        #add the nos
        no3=`expr $no1 + $no2`
        #Get the old value and then add the new value
         old=`cat svnenv.sh  | grep "export MKCS_RISLABEL" | head -1 | cut -d '"' -f2`
        y=`expr $no1 + $no2`
        new=$y
        old1=`cat svnenv.sh  | grep "export MKCS_RISLABEL" | head -1 | cut -d '"' -f2 | cut -c1-12`
        echo $old1$new
        new1=$old1$new
        echo $old $new
        #change the old value by adding the last digit of the RISLABEL by 1
       echo "sed -i "s/$old/$new1/g" svnenv.sh"
        sed -i "s/$old/$new1/g" svnenv.sh

	echo -e "\nCommitting svnenv.sh to the next version..."
        echo -e "\nsvn ci -m \"changed MKCS_RISLABEL to $new\" svnenv.sh"

                svn ci -m "changed MKCS_RISLABEL to $new" svnenv.sh --username $username --password $password
                sleep 20
                cd ../..
                rm -rf tmp_$build_type
                #Creating par.txt for automated  build email
                echo "build_tag=$build_tag" | tee  par1.txt
                echo "build_type=$build_type" | tee -a par1.txt
        	exit 1
	        # do something as file is empty
fi

rm -rf a2.txt a1.txt ans_diff_$JOIN.txt tag_new.txt log_script.txt tag_name.txt log_script.txt log.txt tmp_$build_type
