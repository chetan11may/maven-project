#!/bin/bash
# create external repo for yum
touch /etc/yum.repos.d/wandisco-svn.repo
echo -e "[WandiscoSVN]" > /etc/yum.repos.d/wandisco-svn.repo
echo "name=Wandisco SVN Repo" >> /etc/yum.repos.d/wandisco-svn.repo
echo "baseurl=http://opensource.wandisco.com/rhel/\$releasever/svn-$1/RPMS/\$basearch/" >> /etc/yum.repos.d/wandisco-svn.repo
echo "enabled=1" >> /etc/yum.repos.d/wandisco-svn.repo
echo "gpgcheck=0" >> /etc/yum.repos.d/wandisco-svn.repo

# WARNING:
yum remove subversion
yum clean all
yum install subversion
svn --version