use strict;
use warnings;

 
print "How old are you? ";
my $age = <STDIN>;
if ($age < 13) {
    print "You are too young for this\n";
    exit 0;
	die ("terminating it");
	exit 1;
}
 
print "Doing some stuff ...\n";