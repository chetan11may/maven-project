#!/usr/bin/perl -w
use strict;
use Win32::OLE qw(in with);
use Win32::OLE::Const 'Microsoft Excel';
$Win32::OLE::Warn = 3;                                # die on errors...
my $Excel = Win32::OLE->GetActiveObject('Excel.Application')
    || Win32::OLE->new('Excel.Application', 'Quit');  # get already active Excel
                                                      # application or open new
my $Book = $Excel->Workbooks->Open("D:\\book.xlsx"); # open Excel file
my $Sheet = $Book->Worksheets(1);  
foreach my $row(1..10)
{      
	foreach my $col(1..10)  
	{           # select worksheet number 1
  my $array = $Sheet->Cells($row,$col)->{'Value'};
  print $array,"\t"; 
  }     
  print "\n\n";
} # get the contents
$Book->Close;
