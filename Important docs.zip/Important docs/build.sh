#!/bin/bash
##*******************************************************************************
# FILE NAME:
#     build.sh
#
# DESCRIPTION:
#     Script for Generating Build for FLEXI MULTIRADIO 10/ GFC 1.0
#
# Product:
#     EP SW
#
# REVISION HISTORY
# Date              Author              REASON
# 26/12/2016        Latha D O          [GF17] Added check for som_bmgw binary
# 30/06/2015        Nikhil Sharad      [SWCR.2645] Added check for RPSWLogCollector binary and script 
# 05/02/2015        Vinay Bachu        [GF16] updated for FXEE RG602481 implementation
#                                      Handling rfm3.tgz or RM binary for FXEE/FXED Hardware
# 01/02/2015        Namratha S.         [GF_GSM16] BM integration into GSM build enironment
# 24/03/2014        Shilpa Kamra        [GF1.0] removed som3 and som4 from log file 
#                                       and correct options in log file
# 14/03/2014        Shilpa Kamra        [GF1.0] Removing btspack_log form A53 as 
#                                       per request from CM.
# 10/03/2014        Mohd Gufran Khan    [GF1.0] SWCR 1779 supported.
# 22/01/2014        Trung Huynh         [GF1.0] Take merge for 41907ESPE07
#                                               Enhancement to extend build number beyond 255(FFx)
# 03/10/2013        Vivek Kumar Dutta   [GFC1.0]Bug784:pcf.xml file added in package
# 26/02/2013        Vivek Kumar Dutta   [GFC1.0]Modified to supp lab & prod build
# 25/02/2013        Vivek Kumar Dutta   Script modified for selective download
# 26/12/2013        Vivek Kumar Dutta   Updated path of fupper.sh file
#                                       as suggested by NTT-TRS team
# 21/12/2012        Vivek Kumar Dutta   Added handling for TRX A50/A53 binary
# 29/11/2012        Ghanshyam Malakar   Fixed bug724
# 12/12/2011        E.Placidi           Changed for Christmas cleaning 
# 11/08/2011        G.Calloni           Changed for FLEXI MULTIRADIO 10 (Fsm3b) 
#
# 21/09/2010        Divya Vij           [EX4A]:meswtrx.ehx has been changed
#                                       again to meswtrx.ehx.bz2.
# 17/09/2010        Divya Vij           [EX4A]:meswtrx.ehx.bz2 has been changed
#                                       to meswtrx.ehx.
# 07/09/2009        Savita Sood      	ME1: RFM File Split Implemented (Ankit Gupta)
#
# 25/08/2009        Utkarsh Malik       Added RMGW task functionality
# 23/04/2009        Vikrant Grover      ME1: Replaced RTCM with RP3M task
# 26/06/2008        Sandeepan Kumar     [EP3]Updated for A5/3 Ciphering feature
# 29/11/2006        Gaurav Das Gupta    pr2985c01 Updated for split in TRS files
#                                       Removed A52 package.Updated AF names
# 24/08/2006        Shweta Vyas         Fixed pronto pr2985C01. 
#                                       Added a support for SM4. 
# 01/06/2006        Hitendra Rawat      corrected path from .../btsom/som to
#                                       .../som also changed names in the 
#                                        script for IR3
# 10/05/2006        Hitendra Rawat      Changed the scripts for new file system
#                                       for IR3
#
# 30/03/2006        Ashish Jain         Added support to create three packages
#                                       A50/A51/A52
# 22/12/2005        Shweta Vyas         Added temporary folder in script(tar_files,srv)
# 17/06/2005        Ashish Jain         Initial Draft
#
# 12/01/2007        Satish Kumar        Changed the file system for new naming
#                                       conventionfor IR4
# 
# 14/02/2007        Priyanka Jindal     Modified to generalize and modularize the file and 
#                                       stores and uses information from text file.   
#
# 21/02/2007        Priyanka Jindal     Modified to check 
#                                        1) To allow user to create selective AFs.  
#                                        2) To check whether all versions are as per format XX.YY-ZZ
#                                        3) To increase support for higher version.
# 
# 28/03/2007        Priyanka Jindal     To generate AFs as per output from Dirk script 
# 
# 09/04/2007        Priyanka Jindal     Modified to do binary comparison by function compare_binary. 
# 10/04/2007        Priyanka Jindal     Modiifed to run script in two modes
#                                         1)Forecfully
#                                         2)By comparing binary 
#
# 11/04/2007        Priyanka Jindal     Modiifed to run script in three modes
#                                         1)Forecfully
#                                         2)By comparing binary with previous build
#                                         3)By comparing binary with baseline build and then 
#                                           with previous build
#
# 
# 12/04/2007        Priyanka Jindal      Updated for logging infomation. 
#
# 17/04/2007        Priyanka Jindal 	 Updated to add debug file information.
# 
# 23/04/2007        Priyanka Jindal      Modified to isolate version and names of files 
#                                        and added baseline parameter.
# 12/06/2007        Priyanka Jindal      Incorporated Review comments
#
# 21/06/2007        Gaurav/Priyanka      Som Binary Splitted
#  
# 27/06/2007        Gaurav/Priyanka      Included FTM Binary split.
#Copyright 2005, NOKIA
#*****************************************************************************

 VOB_PATH=${USR_LOCAL_DIR}
 DATE=`date +%d%m%y%H%M%S`
 BUILD_PATH=${USR_LOCAL_DIR}/som/build
 DEBUG_FILE=${BUILD_PATH}/debug${DATE}.txt
 LOG_FILE=${BUILD_PATH}/log${DATE}.txt
 ERROR_FILE=${BUILD_PATH}/error_log${DATE}.txt
 VERSION_FILE=${BUILD_PATH}/version_file.txt
 INPUT_FILE=${BUILD_PATH}/input${DATE}.txt
 BINARY_FILES=${BUILD_PATH}/binary${DATE}.txt
 globVar=""
 BM_REL=`grep -w BM_REL ${USR_LOCAL_DIR}/itrWimax/images/Linux-octeon2-fct/platform_versions |cut -d= -f2`
 GLOBAL_ENV_REL=`grep -w GLOBAL_ENV ${USR_LOCAL_DIR}/itrWimax/images/Linux-octeon2-fct/platform_versions |cut -d= -f2`
 BM_SCM_LOC=/linux_builds/BTS_SW_Tools/BM

 \rm -rf ${VOB_PATH}/do_store/wmx/Linux-octeon2-fct/image/dll/libCCS.so
 \rm -rf ${VOB_PATH}/do_store/wmx/Linux-octeon2-fct/image/dll/libFSMDDAL.so
 \rm -rf ${VOB_PATH}/do_store/wmx/Linux-octeon2-fct/image/dll/libpthread.so
 \rm -rf ${VOB_PATH}/do_store/wmx/Linux-octeon2-fct/image/dll/libpthread.so.0
 \rm -rf ${VOB_PATH}/do_store/wmx/Linux-octeon2-fct/image/dll/libpthread-2.9.so

 #FSM3_SOM
 #TAR=${USR_LOCAL_DIR}/apps/gnu/SunOS/bin/tar
 GZIP=${USR_LOCAL_DIR}/apps/gnu/Linux/bin/gzip
 TAR=${USR_LOCAL_DIR}/apps/gnu/Linux/bin/tar
     version_info=`${TAR} --version 2>/dev/null`
     output=`echo ${version_info} | grep -c GNU`
     if test  ${output} = "1"
     then
         TAR=${TAR}' -P --owner=root --group=root --numeric-owner -b1'
     fi
 #FSM3_SOM
 #RM=${USR_LOCAL_DIR}/apps/gnu/SunOS/bin/rm 
 RM=${USR_LOCAL_DIR}/apps/gnu/Linux/bin/rm 
# AF_BUILD=ep_tools/bin/af_build
 AF_BUILD=ep_tools/bin/af_build
 AF_FILES=${BUILD_PATH}/af_files
# AF_FILES_EP=${BUILD_PATH}/af_files_EP 
err()
{
red='\e[0;31m'
NC='\e[0m'
echo -e ${red}${1}${NC}
}


#*******************************************************************************
#
#  FUNCTION NAME:    dec_to_hex
#
#  DESCRIPTION:      This function converts decimal value to hexdecimal value. 
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          hexdecimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
dec_to_hex() {
  echo "Entry trace, Function:dec_to_hex, Parameter Passed is: ${*}" >> ${DEBUG_FILE}
  local dec2hex_ret=""
  local dec2hex_resVarName=$2
  dec2hex_ret=$(echo -e "$1" |  awk '{ printf "%02X", $_  }') 
  #printf "%02X" $1
  if [[ "$dec2hex_resVarName" ]]; then
    eval $dec2hex_resVarName="'$dec2hex_ret'"
  else
    echo "$dec2hex_ret"
  fi
echo "Exit trace, Function:dec_to_hex" >> ${DEBUG_FILE}
}      

#*******************************************************************************
#
#  FUNCTION NAME:    dec_to_alpha
#
#  DESCRIPTION:      This function converts decimal value to alpha hex value. 
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          alpha hexdecimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES: unit place digit will be hex and tens digit will be from {0..9A..Z}
#
#*******************************************************************************
dec_to_alpha() {
  echo "Entry trace, Function:dec_to_alpha, Parameter Passed is: ${*}" >> ${DEBUG_FILE}
  local dec2alpha_ret=""
  local dec2hex_resVarName=$2
  declare -a digit=(0 1 2 3 4 5 6 7 8 9 A B C D E F G H I J K L M N O P Q R S T U V W X Y Z);
  local first_digit=`expr $1 % 16`
  local next_digit=`expr $1 / 16`
  local dec2alpha_ret=${digit[$next_digit]}${digit[$first_digit]}
  
  if [[ "$dec2hex_resVarName" ]]; then
    eval $dec2hex_resVarName="'$dec2alpha_ret'"
  else
    echo "$dec2alpha_ret"
  fi
echo "Exit trace, Function:dec_to_alpha" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    hex_to_dec
#
#  DESCRIPTION:      This function converts hexdecimal value to decimal value. 
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          decimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
hex_to_dec() {
  echo "Entry trace, Function:hex_to_dec, Parameter Passed is: ${*}" >> ${DEBUG_FILE}
  local hex2dec_ret=""
  local hex2dec_resVarName=$2
    hex2dec_ret=`printf "%d" 0x$1`
  if [[ "$hex2dec_resVarName" ]]; then
    eval $hex2dec_resVarName="'$hex2dec_ret'"
  else
    echo "$hex2dec_ret"
  fi
echo "Exit trace, Function:hex_to_dec" >> ${DEBUG_FILE}
}      
#*******************************************************************************
#
#  FUNCTION NAME:    print_func
#
#  DESCRIPTION:      This function prints data in a format.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
print_func () { 
file_name=`ls $1 | grep ${2}_*`
echo "*******************************************">> \
      ${BUILD_PATH}/btspack_${pack_version}/btspack_log

    echo "*******************************************"
echo "Copying $file_name from ${1} folder">> \
       ${BUILD_PATH}/btspack_${pack_version}/btspack_log

echo "*******************************************">> \
      ${BUILD_PATH}/btspack_${pack_version}/btspack_log
}

#*******************************************************************************
#
#  FUNCTION NAME:    base_no_check
#
#  DESCRIPTION:      This function checks whether baselline enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
base_no_check () { 


    echo "Entry trace, Function:base_no_check" >> ${DEBUG_FILE}
    while [ /bin/true ]
    do  
        read base
        #dec_to_hex $base base_hex
        dec_to_alpha $base base_hex
        base_hex=`echo $base_hex | sed -e "s/0x//"`
        base="$base_hex""X"
        echo "base: $base"  
        if test `echo ${base} | wc -c` -ne 4   
        then 
            echo "Please enter baseline in decimal number"
            continue
        fi    

        first_digit=`echo ${base} | cut -c1-1`
        case  "${first_digit}" in

            [!0-9A-Za-z]) echo "First digit wrong. Please re-enter value again[0-9 A-Z]" 
            continue  ;;

        esac


        second_digit=`echo ${base} | cut -c2-2`

        case  "${second_digit}" in

            [!0-9A-Fa-f]) echo "Last digit wrong. Please re-enter value again[0-9 A-F]" 
            continue  ;;

            *) break;;
        esac


    done 

    echo "Exit trace, Function:base_no_check" >> ${DEBUG_FILE}
}




#*******************************************************************************
#
#  FUNCTION NAME:    version_check
#
#  DESCRIPTION:      This function checks whether version enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

version_check () { 


    echo "Entry trace, Function:version_check" >> ${DEBUG_FILE}
    while [ /bin/true ]
    do  
        read version
        if test `echo ${version} | wc -c` -ne 9 
        then 
            echo "Please enter version as UV.WX-YZ"
            continue
        fi   



        u_digit=`echo ${version} | cut -c1-1`
#        case  "${u_digit}" in

#            [!0]) echo "Wrong value entered for U. 'U' should be zero" 
#            continue  ;;

#        esac

        v_digit=`echo ${version} | cut -c2-2`
        case  "${v_digit}" in

            [!0-9A-Fa-f]) echo "Wrong value entered for V. 'V' should be hexadecimal" 
            continue  ;;

        esac

 
        release=`echo ${version} | cut -c3-3`
        if test ${release} != "."
        then
            echo "Wrong Release Number.Please re-enter value again"
            continue

        fi

        w_digit=`echo ${version} | cut -c4-4`
        case  "${w_digit}" in

            [!0-9A-Fa-f]) echo "Wrong value entered for W. 'W' should be hexadecimal" 
            continue  ;;

        esac

        x_digit=`echo ${version} | cut -c5-5`
        case  "${x_digit}" in

            [!0-9A-Fa-f]) echo "Wrong value entered for X. 'X' should be hexadecimal" 
            continue  ;;

        esac

        subrelease=`echo ${version} | cut -c6-6`
        if test ${subrelease} != "-"
        then
            echo "Wrong SubRelease Number.Please re-enter value again"

            continue
        fi 


        y_digit=`echo ${version} | cut -c7-7`
        case  "${y_digit}" in

            [!0-9A-Fa-f]) echo "Wrong value entered for Y. 'Y' should be hexadecimal" 
            continue  ;;

        esac


        z_digit=`echo ${version} | cut -c8-8`

        case  "${z_digit}" in

            [!0-9A-Fa-f]) echo "Wrong value entered for Z. 'Z' should be hexadecimal" 
            continue  ;;

            *) break;;
        esac


    done 

    echo "Exit trace, Function:version_check" >> ${DEBUG_FILE}
}




#*******************************************************************************
#
#  FUNCTION NAME:    ext_check
#
#  DESCRIPTION:      This function checks whether ext and ext1  enter is as per  
#                    format or not.
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#****************************************************************************
ext_check () { 

    echo "Entry trace, Function:ext_check " >> ${DEBUG_FILE}

 
    while [ /bin/true ]
    do  
        read extension
        if test `echo ${extension} | wc -c` -ne 5 
        then 
            echo "Please enter extenion for package as XXXX"
            continue

        fi
        break 
    done

    echo "Exit trace, Function:ext_check" >> ${DEBUG_FILE}
}


#*******************************************************************************
#
#  FUNCTION NAME:    del_func
#
#  DESCRIPTION:      This function deletes directory/file if it exists.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
del_func() {
echo "Entry trace, Function:del_func called to delete ${1}, if it already exists " >> \
      ${DEBUG_FILE} 
              ${RM} -rf ${1} 2>&1 >> ${DEBUG_FILE} 
echo "Exit trace, Function:del_func" >> ${DEBUG_FILE}
}
#*******************************************************************************
#
#  FUNCTION NAME:    compare_binary
#
#  DESCRIPTION:      This function do comparison of binaries using md5sum.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


compare_binary () {


    echo "Entry trace, Function:compare_binary, Compares : ${1} ${2} in folder ${3}" >> ${DEBUG_FILE}
    AF_FOLDER=${3}
    TAR_PATH=${BUILD_PATH}/tar_files

    cd ${BUILD_PATH}/
    del_func tmp

    mkdir ${BUILD_PATH}/tmp
    mkdir ${BUILD_PATH}/tmp/gzip_af
    mkdir ${BUILD_PATH}/tmp/gzip_tar

    mkdir ${BUILD_PATH}/tmp/gzip_af/tar 
    mkdir ${BUILD_PATH}/tmp/gzip_tar/tar 


    echo "*******************************"  >> ${BINARY_FILES}
    echo "Listing changed binaries in $1" >> ${BINARY_FILES}
    echo "*******************************"  >> ${BINARY_FILES}

    flag1=2
    null_string=" " 
    cp ${TAR_PATH}/${2}* ${BUILD_PATH}/tmp/gzip_tar/

    cp ${AF_FOLDER}/${1}* ${BUILD_PATH}/tmp/${1} >& ${ERROR_FILE}
    if test "${?}" != "0"
    then 
        flag1=1
        echo "Application file doesn't exists in folder ${AF_FOLDER} " >>  ${DEBUG_FILE}

    else            
        tail -c +257 ${BUILD_PATH}/tmp/${1} > ${BUILD_PATH}/tmp/gzip_af/${1}

        gzip -d ${BUILD_PATH}/tmp/gzip_af/${1}  >& ${ERROR_FILE}
        gzip -d ${BUILD_PATH}/tmp/gzip_tar/${2}* >& ${ERROR_FILE}

        cd ${BUILD_PATH}/tmp/gzip_af/tar/
        if [ ! -f   ${BUILD_PATH}/tmp/gzip_af/${1}.out ]
        then
            ${TAR} -xf ${BUILD_PATH}/tmp/gzip_af/${1}
            rm ${BUILD_PATH}/tmp/gzip_af/${1}
        else
            ${TAR} -xf ${BUILD_PATH}/tmp/gzip_af/${1}.out 
            rm ${BUILD_PATH}/tmp/gzip_af/${1}.out
        fi

        cd ${BUILD_PATH}/tmp/gzip_tar/tar/
        ${TAR} -xf ${BUILD_PATH}/tmp/gzip_tar/${2}*.tar 
        rm ${BUILD_PATH}/tmp/gzip_tar/${2}*.tar

        dir=${BUILD_PATH}/tmp/gzip_tar
        #read a           
        count=`find ${dir} ! -type d | wc -l`
        #find $dir ! -type d -print
        #echo "count of file $count"

        cd ${BUILD_PATH}/tmp/gzip_af
        count1=`find . ! -type d | wc -l`
        #find . ! -type d -print

        #echo "count of file in tar $count1" 

        diff_count=`expr ${count}  - ${count1}`
        if test ${diff_count} != 0
        then 
            #echo "files diferent"
            flag1=1
            echo "Number of binaries different" >>${DEBUG_FILE}
            echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}
            echo "Binary Moved in/out of Application file ${1}" >> ${BINARY_FILES}
        else 

            echo " Checksum of AF files binary     Checksum of Tar file binary    file name"  >>\
            ${DEBUG_FILE}
            for file in `find .  ! -type d -print`
            do
                info_file=`echo ${file}| grep '\.info'`
                if test "${?}" !=  "0"  
                then
                    chksum1=`md5sum ${file}`
                    chksum1=`echo ${chksum1} | cut -d " " -f -1`

                    if [ ! -f   ${dir}/${file} ]
                    then 
                        flag1=1
                        echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}

                        echo "Binary ${file} moved out of AF file" >>\
                        ${DEBUG_FILE}
                    else   
                        chksum=`md5sum ${dir}/${file}`
                        chksum=`echo ${chksum} | cut -d " " -f -1`
                        #echo "$chksum $chksum1 $file"
                        echo "${chksum1}    ${chksum}     ${file}">>${DEBUG_FILE}
                        if test ${chksum1} = ${chksum}
                    then
                        #flag1=2   
                        #echo $flag1 
                        echo "............."  >>${DEBUG_FILE}

                    else 
                        flag1=1
                        echo "Application File ${1}_IR04.A5X changed">>${DEBUG_FILE}
                        echo "${file} changed" >> ${BINARY_FILES}
                        #break
                    fi
                fi
            fi

        done
    fi

fi
echo "Exit trace, Function:compare_binary" >> ${DEBUG_FILE} 

}


#*******************************************************************************
#
#  FUNCTION NAME:    binary_init
#
#  DESCRIPTION:      This function initiate comparison of binaries.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
binary_init () {

    echo "Entry trace, Function:binary_init Parameter Passed : ${@}" >> ${DEBUG_FILE}

    if test ${1} = "2"

    then

        compare_binary ${2} ${3} ${AF_FILES}
        flag=${flag1}
        if test  "${flag}" = "1" 
        then 
            echo "${2}_IR04.A5X :changed" >> ${INPUT_FILE}
        else  
            echo "${2}_IR04.A5X :unchanged" >> ${INPUT_FILE}
            echo "No files associated with ${2} changed" >> ${BINARY_FILES}


        fi

    fi

}

#*******************************************************************************
#
#  FUNCTION NAME:    secure_command
#
#  DESCRIPTION:      This function checks whether command executed successfully or not.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
secure_command () {
echo "Entry trace, Function:secure_command command to execute is: ${@}" >> ${DEBUG_FILE}
${@}
if test ${?} -ne 0
   then 
       echo " command ${@} is not successfull. Please check and re-run script"
       exit
fi 
echo "Exit trace, Function:secure_command" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    is_present
#
#  DESCRIPTION:      This function checks file exist or not  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
is_present () {
echo "Entry trace, Function:is_present command to execute is: ${@}" >> ${DEBUG_FILE}
test -e ${@}
if test ${?} -ne 0
   then 
       echo " file ${@} is missing. Please check Compilation"
       exit
fi 
echo "Exit trace, Function:secure_command" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    binary_check
#
#  DESCRIPTION:      This function checks whether command executed successfully or not.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
binary_check () {
echo "Entry trace, Function:binary_check command to execute is: ${@}" >> ${DEBUG_FILE}

SOM_PATH=${VOB_PATH}/som
#Checking common SOM binaries
is_present ${SOM_PATH}/bin/som_build_info  
is_present ${SOM_PATH}/bin/som_lapd   
is_present ${SOM_PATH}/bin/som_qdl
is_present ${SOM_PATH}/bin/som_iua_sctp    
is_present ${SOM_PATH}/bin/som_q1mgt
#Checking SOM binaries in fb directory
is_present ${SOM_PATH}/bin/fb/som_ah  
is_present ${SOM_PATH}/bin/fb/som_btsrv   
is_present ${SOM_PATH}/bin/fb/som_hwmgt  
is_present ${SOM_PATH}/bin/fb/som_persm  
is_present ${SOM_PATH}/bin/fb/som_rp3m  
#is_present ${SOM_PATH}/bin/fb/som_scgw  
is_present ${SOM_PATH}/bin/fb/som_testm
is_present ${SOM_PATH}/bin/fb/som_bc  
is_present ${SOM_PATH}/bin/fb/som_commis  
is_present ${SOM_PATH}/bin/som_llc    
is_present ${SOM_PATH}/bin/fb/som_rmgw   
is_present ${SOM_PATH}/bin/fb/som_rp3r  
is_present ${SOM_PATH}/bin/fb/som_tcs
is_present ${SOM_PATH}/bin/fb/som_bmgw
is_present ${SOM_PATH}/bin/fb/RPSWLogCollector
is_present ${SOM_PATH}/bin/fb/RPSWLogCollector.sh

echo "Exit trace, Function:binary_check" >> ${DEBUG_FILE}
}


#*******************************************************************************
#
#  FUNCTION NAME:    af_file_create
#
#  DESCRIPTION:      This function will generate AF file based on input file.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE; 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************


af_file_create () { 


echo "Entry trace, Function:af_file_create Parameter Passed are: ${*}" >> ${DEBUG_FILE}

check=`grep "${1}" ${INPUT_FILE} |  cut -d \: -f 2`
if test "${check}" != changed

         then
            if test "${check}" = "1"          
                then
  
                       secure_command cp ${AF_FILES_EP}/${1}*  ${TAR_PATH}/
                       print_func  ${AF_FILES_EP} ${1}
                
            else 
                       print_func  ${AF_FILES} ${1}
                       secure_command cp  ${AF_FILES}/${1}*  ${TAR_PATH}/
            fi
else

          secure_command ../${AF_BUILD} -r"${ext}""${2}" -n${3} -e${4} -V${5} \
              ${6} >> ${BUILD_PATH}/btspack_${pack_version}/btspack_log

 
fi

echo "Exit trace, Function:af_file_create" >> ${DEBUG_FILE}
}
#*******************************************************************************
#
#  FUNCTION NAME:    af_file_create_ext_3
#
#  DESCRIPTION:      This function will generate AF file based on input file.  
#                    for A53                
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE; 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
 
af_file_create_ext_3 () { 


echo "Entry trace, Function:af_file_create_ext_3 Parameter Passed are: ${*}" >> ${DEBUG_FILE}

check=`grep "${1}" ${INPUT_FILE} |  cut -d \: -f 2`
if test "${check}" != changed

         then
            if test "${check}" = "1"          
                then
  
                       secure_command cp ${AF_FILES_EP}/${1}*  ${TAR_PATH}/
                       print_func  ${AF_FILES_EP} ${1}
                
            else 
                       print_func  ${AF_FILES} ${1}
                       secure_command cp  ${AF_FILES}/${1}*  ${TAR_PATH}/
            fi
else

         secure_command ../${AF_BUILD} -r"${ext_3}""${2}" -n${3} -e${4} -V${5} \
             ${6} >> ${BUILD_PATH}/btspack_${pack_version_3}/btspack_log

 
fi

echo "Exit trace, Function:af_file_create_ext_3" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    create_ver_file
#
#  DESCRIPTION:      This function creates version file.     
#            
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************
# create_ver_file shall be called when insid the TAR_PATH !!!!!!!!

create_ver_file () { 
    echo "Entry trace, Function:create_ver_file" >> ${DEBUG_FILE}
    #taking the name of extensions and Package files from user

    echo "Enter extension for package without ciphering A50:  "
    ext_check
    ext=${extension}
    
    
    echo "Enter extension for package with ciphering A53:  "
    ext_check
    ext_3=${extension}
    
    echo "Enter the version of BTS Package (UV.WX-YZ) "
    version_check  
    pack_version=${version}
 
    
    echo "Enter Baseline Number in Decimal "
    base_no_check
    #read base
    base_no=${base}

    echo "Do you want to continue with previous Af Versions: yes, no"
    read check
    if test ${check} = "y" || test ${check} = "Y" || test ${check} = "yes" \
        || test ${check} = "YES"
    then

        btsconf_version=`grep  "BTS Configuration"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_1=`grep "TAR_1"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_2=`grep "TAR_2"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_3=`grep "TAR_SYS_3"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_4=`grep "TAR_SYS_4"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_5=`grep "TAR_SYS_5"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_6=`grep "TAR_SYS_6"   ${VERSION_FILE} | cut -d \: -f 2 `
        trs_version_7=`grep "TAR_SYS_7"   ${VERSION_FILE} | cut -d \: -f 2 `
	trs_version_8=`grep "TAR_SYS_8"   ${VERSION_FILE} | cut -d \: -f 2 `
        som_version_1=`grep "som1"   ${VERSION_FILE} | cut -d \: -f 2 `
        som_version_2=`grep "som2"   ${VERSION_FILE} | cut -d \: -f 2 `
        trx_version_1=`grep "trx1"   ${VERSION_FILE} | cut -d \: -f 2 `
        trx_version_2=`grep "trx2"   ${VERSION_FILE} | cut -d \: -f 2 `
        rfm_version_1=`grep "rfm1"     ${VERSION_FILE}  | cut -d \: -f 2 `
        rfm_version_2=`grep "rfm2"   ${VERSION_FILE}  | cut -d \: -f 2 `
        rfm_version_3=`grep "rfm3"   ${VERSION_FILE}  | cut -d \: -f 2 `


        echo " User selected to continue with same application file versions">>${LOG_FILE}



    else
        echo " User selected to change version information">>${LOG_FILE}

        echo "Do you want Af Versions to be same as Pack version: yes, no"
        read check
        if test ${check} = "y" || test ${check} = "Y" || test ${check} = "yes" \
            || test ${check} = "YES"
        then
            btsconf_version=${pack_version}
            trs_version_1=${pack_version}
            trs_version_2=${pack_version}
            trs_version_3=${pack_version}
            trs_version_4=${pack_version}
            trs_version_5=${pack_version}
            trs_version_6=${pack_version}
            trs_version_7=${pack_version}
            trs_version_8=${pack_version}
	    som_version_1=${pack_version}
            som_version_2=${pack_version}
            som_version_3=${pack_version}
            som_version_4=${pack_version}
            trx_version_1=${pack_version}
            trx_version_2=${pack_version}
            rfm_version_1=${pack_version}
            rfm_version_2=${pack_version}
            rfm_version_3=${pack_version}

            echo " User selected to continue with version information as pack Version ">>\
            ${LOG_FILE}


        else 
            echo " User selected to enter new versions for application files ">>\
            ${LOG_FILE}

            echo "enter the version of BTS Configuration File"
            version_check 
            btsconf_version=${version}

            echo "enter the version of TAR_1"
            version_check 
            trs_version_1=${version}

            echo "enter the version of TAR_2"
            version_check 
            trs_version_2=${version}

            echo "enter the version of TAR_SYS_3"
            version_check 
            trs_version_3=${version}

            echo "enter the version of TAR_SYS_4"
            version_check 
            trs_version_4=${version}

            echo "enter the version of TAR_SYS_5"
            version_check 
            trs_version_5=${version}

            echo "enter the version of TAR_SYS_6"
            version_check 
            trs_version_6=${version}

            echo "enter the version of TAR_SYS_7"
            version_check 
            trs_version_7=${version}

	    echo "enter the version of TAR_SYS_8"
            version_check 
            trs_version_8=${version}
            
            echo "enter the version of som1"
            version_check  
            som_version_1=${version}

            echo "enter the version of som2"
            version_check 
            som_version_2=${version}

            echo "enter the version of trx1(i.e DSP A50)"
            version_check 
            trx_version_1=${version}
            echo "enter the version of trx1(i.e DSP A53)"
            version_check 
            trx_version_2=${version}

            echo "enter the version of RFM1"
            version_check 
            rfm_version_1=${version}

            echo "enter the version of RFM2"
            version_check 
            rfm_version_2=${version}
            echo "enter the version of RFM3"
            version_check 
            rfm_version_3=${version}

        fi
    fi

    echo "The versions entered are" > ${VERSION_FILE}
    echo "Extension for package with ciphering A50 :${ext}" >> ${VERSION_FILE}
    echo "Extension for package with ciphering A53 :${ext_3}" >> ${VERSION_FILE}
    echo "Baseline Number for package              :${base_no}">> ${VERSION_FILE}
    echo "BTS Package                              :${pack_version}" >>${VERSION_FILE}
    echo "BTS Configuration                        :${btsconf_version}">>${VERSION_FILE}
    echo "TAR_1                                    :${trs_version_1}">>${VERSION_FILE}
    echo "TAR_2                                    :${trs_version_2}" >>${VERSION_FILE}
    echo "TAR_SYS_3                                :${trs_version_3}" >>${VERSION_FILE}
    echo "TAR_SYS_4                                :${trs_version_4}" >>${VERSION_FILE}
    echo "TAR_SYS_5                                :${trs_version_5}" >>${VERSION_FILE}
    echo "TAR_SYS_6                                :${trs_version_6}" >>${VERSION_FILE}
    echo "TAR_SYS_7                                :${trs_version_7}" >>${VERSION_FILE}
    echo "TAR_SYS_8                                :${trs_version_8}" >>${VERSION_FILE}
    echo "som1                                     :${som_version_1}" >>${VERSION_FILE}
    echo "som2                                     :${som_version_2}">>${VERSION_FILE}
    echo "trx1                                     :${trx_version_1}" >>${VERSION_FILE}
    echo "trx2                                     :${trx_version_2}" >>${VERSION_FILE}
    echo "rfm1                                     :${rfm_version_1}" >>${VERSION_FILE}
    echo "rfm2                                     :${rfm_version_2}" >>${VERSION_FILE}
    echo "rfm3                                     :${rfm_version_3}" >>${VERSION_FILE}

    cat ${VERSION_FILE}  >> ${LOG_FILE}
    cat ${VERSION_FILE}


    echo "Exit trace, Function:create_ver_file" >> ${DEBUG_FILE}
}
#*******************************************************************************
#
#  FUNCTION NAME:    create_af_files
#
#  DESCRIPTION:      This function will generate AF files based on tgz files
#                    present on ./tar_files location
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE; 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

create_af_files () { 
    echo "Entry trace, Function:create_af_files" >> ${DEBUG_FILE}
    local tarN=1;
    local somN=1;
    local rfmN=1;
    local trxN0=1;
    local trxN3=1;
    local afN=0;
    local match_path=".tgz"

    ${BUILD_PATH}/btspack_${pack_version}/btspack_log
    files=( `ls ./*${match_path}` );
    echo "found ${#files[@]} tgz"
    for f in  $(seq 0 $((${#files[@]} - 1)))
    do
        file="${files[$f]}"
        b=$(basename $file)
        pkt=$(echo $b | sed -e "s/$match_path.*//")
        echo "processing $file $b $pkt "
    if  [[ $(echo $pkt | sed -ne "/tar/Ip") ]]
    then
       if [[ ! $(echo $globVar | sed -ne "/SM/Ip") ]]
       then
         globVar+=" SM*"
       fi
       afN=$[$tarN+-1]
       echo "af_file_create SM$tarN ${base_no} 0 $afN ${pack_version} $b"
	if [[  "$tarN" == "8" ]]
       	then

                echo "af_file_create SM$tarN ${base_no} 0 15 ${pack_version} $b"
		secure_command af_file_create SM$tarN ${base_no} 0 15 ${pack_version} $b
	else
		secure_command af_file_create SM$tarN ${base_no} 0 $afN ${pack_version} $b
	fi   
tarN=$[$tarN+1]
    elif [[ $(echo $pkt | sed -ne "/SOM/Ip") ]]
    then
       if [[ ! $(echo $globVar | sed -ne "/SO/Ip") ]]
       then
         globVar+=" SO*"
       fi       
       afN=$[$somN+6]
       secure_command af_file_create SO$somN ${base_no} 0 $afN ${pack_version} $b
        somN=$[$somN+1]
    elif [[ $(echo $pkt | sed -ne "/rfm/Ip") ]]
    then
       if [[ ! $(echo $globVar | sed -ne "/RM/Ip") ]]
       then
         globVar+=" RM*"
       fi
       
 
    if [[  "$rfmN" == "3" ]]
	then
	afN=$[$rfmN+13]
	else
       afN=$[$rfmN+11]
	fi
	
       secure_command af_file_create RM$rfmN ${base_no} 0 $afN ${pack_version} $b
       rfmN=$[$rfmN+1]
     elif [[ $(echo $pkt | sed -ne "/trx/Ip") ]]
    then
       if [[ ! $(echo $globVar | sed -ne "/TM/Ip") ]]
       then
         globVar+=" TM*"
       fi       
            if [[ $(echo $pkt | sed -ne "/trx1/Ip") ]]
            then
                afN=$[$trxN0+10]
                secure_command af_file_create TM${trxN0}R${ext} ${base_no} 0 $afN ${pack_version} $b
                trxN=$[$trxN0+1]
            fi
            if [[ $(echo $pkt | sed -ne "/trx2/Ip") ]]
            then
                afN=$[$trxN3+10]
                secure_command af_file_create_ext_3 TM${trxN3}R${ext_3} ${base_no} 0 $afN ${pack_version_3} $b
                trxN=$[$trxN3+1]
            fi
    fi
  done
    cat ${VERSION_FILE}  >> ${LOG_FILE}
    cat ${VERSION_FILE}
  echo "Exit trace, Function:create_ver_file" >> ${DEBUG_FILE}
  
    cat ${INPUT_FILE}

    secure_command cd ${BUILD_PATH}
    packVar_A50=`echo ${globVar} |sed -e "s/TM*/TM*${ext}/"`
    packVar_A53=`echo ${globVar} |sed -e "s/TM*/TM*${ext_3}/"`
echo "GLOB is $globVar"
    echo "packVar_A50 is $packVar_A50"
    echo "packVar_A53 is $packVar_A53"
    echo "Exit trace, Function:create_af_files" >> ${DEBUG_FILE}
}

#*******************************************************************************
#
#  FUNCTION NAME:    extract_fupper
#
#  DESCRIPTION:      This function will extract the containts of fupper image  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          NONE; 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

extract_fupper () {
    echo "Entry trace, Function:extract_fupper" >> ${DEBUG_FILE}
FUPPER=$1
DEST=$2
if [[ -z "$FUPPER" || -z "$DEST" ]]
then
  err "invalid arguments"
  return 1
fi
for i in `ls -d  $DEST/update* ` 
do
  echo "removing old file $i"
  rm -rf $i
done
DATA_MD5_SUM=$(sed -nr "s/^__DATA_MD5_SUM__=([0-9a-f]{32})$/\1/p" "$FUPPER")
echo "extracting fupper tarball..."
sed "1,/^__DATA_STARTS_HERE__$/d" "$FUPPER" > $DEST/update.tar.gz
echo "checking md5sum..."
echo "$DATA_MD5_SUM  $DEST/update.tar.gz" > $DEST/update.tar.gz.md5
md5sum -c $DEST/update.tar.gz.md5
if (( $? ))
then
err "md5sum incorrect, stop"
return 1
fi
tar -zxvf $DEST/update.tar.gz -C $DEST/
    echo "Exit trace, Function:extract_fupper" >> ${DEBUG_FILE}
}
#*******************************************************************************
#
#  FUNCTION NAME:    create_build
#
#  DESCRIPTION:      This function creates build package.  
#             
#  INPUT:            NONE
#
#  OUTPUT:           NONE
#
#  RETURNS:          decimal value 
#
#  GLOBAL DATA REFERENCED: NONE
#
#  CALLED ROUTINES:  NONE
#
#  NOTES:
#
#*******************************************************************************

create_build () {
    echo "Entry trace, Function:create_build" >> ${DEBUG_FILE}
  TRX_PATH=${BUILD_PATH}
  SOM_PATH=${USR_LOCAL_DIR}/som
  RFM_PATH=${BUILD_PATH}
  FTM_PATH=${USR_LOCAL_DIR}/itrBuild/Variants/Linux-octeon2-fct/image/swdownload
  secure_command mkdir -p ${VOB_PATH}/itrWimax/bm
  #FTM_PATH=${USR_LOCAL_DIR}/do_store/wmx/Linux-octeon2-fct/image/swdownload
  CONF_PATH=${BUILD_PATH}
  MF_BUILD=ep_tools/bin/mf_build
  CONFIG_BUILD=${BUILD_PATH}/ep_tools/bin
  PROC=$(uname -p)
  STRIP="/utran/fdd/nodeb/opt/i686-pc-linux-gnu/gcc-4.3.3_10500/bin/mips64-octeon2-linux-gnu-strip"
  CLEARTOOL=/opt/rational/clearcase/bin/cleartool   
    PS_LFS_OS="`grep -w PS_LFS_OS ${USR_LOCAL_DIR}/itrWimax/images/Linux-octeon2-fct/platform_versions |cut -d= -f2`"
    #FUPPER_PATH="/build/ltesdkroot/Platforms/LINUX/${PS_LFS_OS}/platforms/fsm3_octeon2/factory/fsm3_octeon2-fupper_images.sh"
    globvar_A50=""
    globvar_A53=""
  echo "Entry trace, Function:create_build Parameter Passed: $@" > ${DEBUG_FILE}            
    cd ${BUILD_PATH}/
    #trx_bld="GF1_TRX_IR1_BL${trx_bld_tmp}"
    #checking binaries
    binary_check
  del_func som
  echo "copying bm.txz from SCM location(/linux_builds/BTS_SW_Tools/BM/RP_BM_xxxx_yyy_zz/fsmf_target) to itrWimax/bm...... " >> ${DEBUG_FILE}
  secure_command cp ${BM_SCM_LOC}/${BM_REL}/fsmf_target/bm.txz ${VOB_PATH}/itrWimax/bm/
  secure_command mkdir ${BUILD_PATH}/som/
  secure_command mkdir ${BUILD_PATH}/som/bin 
  secure_command mkdir ${BUILD_PATH}/som/lib64
  secure_command mkdir ${BUILD_PATH}/som/rfm
  secure_command mkdir ${BUILD_PATH}/som/trx
  secure_command mkdir ${BUILD_PATH}/som/trx/A53
  secure_command mkdir ${BUILD_PATH}/som/trx/A50
  #Nothing is taken from fupper after DUT(uboot) fix so commenting extraction
  #echo "Extracting fupper ">>${DEBUG_FILE}
  #secure_command extract_fupper ${FUPPER_PATH} ${BUILD_PATH}
  echo "Extracting fupper ">>${DEBUG_FILE}
    #secure_command extract_fupper ${FUPPER_PATH} ${BUILD_PATH}
  #make a temporary "tar_files" folder to store tar and AF's
  
  #make a temporary "tar_files" folder
  del_func ${BUILD_PATH}/tar_files
  secure_command mkdir ${BUILD_PATH}/tar_files
  TAR_PATH=${BUILD_PATH}/tar_files

    cd ${TAR_PATH}
    secure_command ${RM} -rf *.*

    echo "Checked whether version file exists or not............" >> ${DEBUG_FILE}   
	 if test -e ${VERSION_FILE}
        then  
          echo "The versions for new AFs will be:"    

     else
         echo "Version File or AF Build Option file doesn't exists."
         create_ver_file

     fi


     ext=`grep A50 ${VERSION_FILE} | cut -d \: -f 2`
     ext_3=`grep "A53" ${VERSION_FILE} | cut -d \: -f 2`
     base_no=`grep "Baseline" ${VERSION_FILE} | cut -d \: -f 2`
     pack_version=`grep  "BTS Package" ${VERSION_FILE} | cut -d \: -f 2 ` 
     btsconf_version=`grep  "BTS Configuration"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_1=`grep "TAR_1"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_2=`grep "TAR_2"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_3=`grep "TAR_SYS_3"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_4=`grep "TAR_SYS_4"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_5=`grep "TAR_SYS_5"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_6=`grep "TAR_SYS_6"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_7=`grep "TAR_SYS_7"   ${VERSION_FILE} | cut -d \: -f 2 `
     trs_version_8=`grep "TAR_SYS_8"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_1=`grep "som1"   ${VERSION_FILE} | cut -d \: -f 2 `
     som_version_2=`grep "som2"   ${VERSION_FILE} | cut -d \: -f 2 `
     trx_version_1=`grep "trx1"   ${VERSION_FILE} | cut -d \: -f 2 `
     trx_version_2=`grep "trx2"   ${VERSION_FILE} | cut -d \: -f 2 `
     rfm_version_1=`grep "rfm1"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_2=`grep "rfm2"   ${VERSION_FILE}  | cut -d \: -f 2 `
     rfm_version_3=`grep "rfm3"   ${VERSION_FILE}  | cut -d \: -f 2 `
 
    
     echo "Extension for package with ciphering A50 :${ext}" 
     echo "Extension for package with ciphering A53 :${ext_3}" 
     echo "Baseline Number for package              :${base_no}" 
     echo "BTS Package                              :${pack_version}"
     echo "BTS Configuration                        :${btsconf_version}"
     echo "TAR_1                                    :${trs_version_1}"
     echo "TAR_2                                    :${trs_version_2}"
     echo "TAR_SYS_3                                :${trs_version_3}"
     echo "TAR_SYS_4                                :${trs_version_4}"
     echo "TAR_SYS_5                                :${trs_version_5}"
     echo "TAR_SYS_6                                :${trs_version_6}"
     echo "TAR_SYS_7                                :${trs_version_7}"
     echo "TAR_SYS_8                                :${trs_version_8}"
     echo "som1                                     :${som_version_1}"
     echo "som2                                     :${som_version_2}"
     echo "trx1                                     :${trx_version_1}"
     echo "trx2                                     :${trx_version_2}"
     echo "rfm1                                     :${rfm_version_1}"
     echo "rfm2                                     :${rfm_version_2}"
     echo "rfm3                                     :${rfm_version_3}"

     echo "Do you want to continue with same version (y/n)?"
     read choice
     if test ${choice} = "n" || test ${choice} = "N" || test ${choice} = "no"  \
         || test ${choice} = "NO"
     then    
         echo " User selected to enter new versions">>${LOG_FILE}
         create_ver_file
     else
         echo " User selected to continue with same version information">>${LOG_FILE}  
     fi 
     #not needed now
     ext_BTS_CFG_dec=${base_no} 
  secure_command mkdir -p ${FTM_PATH}
  cd ${FTM_PATH}/
  #del_func ${FTM_PATH}/*
  secure_command rm -rf ${FTM_PATH}/*
  #del_func ${FTM_PATH}/srv
  #secure_command mkdir ${FTM_PATH}
  secure_command mkdir ${FTM_PATH}/srv


  #make a temporary "srv" folder
   #clean tar_files folder ${BUILD_PATH}/btspack_log

  cd ${TAR_PATH}
  secure_command ${RM} -rf *.*
  pack_version_3=`echo ${pack_version} | cut -c1-7`3
  #echo ${pack_version_3} 
  btsconf_version_3=`echo ${btsconf_version} | cut -c1-7`3

  #ext_BTS_CFG_dec=${base_no} 
  #ext_SM1_SM5_dec=${base_no}
  #ext_SO1_SO2_dec=${base_no}
  #ext_RM_dec=${base_no}
  #ext_TM_dec=${base_no}

  cd ${BUILD_PATH}
  del_func btspack_${pack_version}
  del_func btspack_${pack_version_3}

  secure_command mkdir btspack_${pack_version}
  secure_command mkdir btspack_${pack_version_3} 
  secure_command mkdir btspack_${pack_version}/A50
  secure_command mkdir btspack_${pack_version_3}/A53

  #Create TRS and SYS PL tar and copy it in tar_files directory */
  echo "make_sys_pkg.pl script running........... " >> ${DEBUG_FILE}   

  cd ${USR_LOCAL_DIR}/itr/integration/scripts
  if test $2 = "1"
  then
      echo "Making Production Build">>${DEBUG_FILE}
      secure_command perl ${BUILD_PATH}/make_sys_trs_pkg.pl -buildfile ${BUILD_PATH}/flashpart.build -buildNo "$ext.$base_no" -buildOpt "PROD" 
  else
      echo "Making Laboratory Build">>${DEBUG_FILE}
      secure_command perl ${BUILD_PATH}/make_sys_trs_pkg.pl -buildfile ${BUILD_PATH}/flashpart.build -buildNo "$ext.$base_no" -buildOpt "LAB" 
  fi


  echo "make_sys_pkg.pl script completed.......... " >> ${DEBUG_FILE} 

     #coping tgz from FTM_PATH to TAR_PATH
  for suffix in "tgz tar tar.bz2"
    do
      for i in `ls ${FTM_PATH}/*.$suffix 2>/dev/null`
                            do
                            echo "try $i"
                            secure_command cp  $i ${TAR_PATH}/
                            done
                            done
  cd ${BUILD_PATH}
  (cd trx/A50; secure_command ${TAR} -cvf ${TAR_PATH}/trx1.tar *.bin)
  (cd trx/A53; secure_command ${TAR} -cvf ${TAR_PATH}/trx2.tar *.bin)
  cd ${BUILD_PATH}
  #secure_command mkdir -p som/srv/
secure_command mkdir -p som/srv/

     secure_command ${TAR} -tvf ${TAR_PATH}/trx1.tar > som/srv/TM1R${ext}.${ext_TM_dec}.info
     secure_command ${TAR} -tvf ${TAR_PATH}/trx2.tar > som/srv/TM1R${ext_3}.${ext_TM_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/trx1.tar som/srv/TM1R${ext}.${ext_TM_dec}.info
     secure_command ${TAR} -rf ${TAR_PATH}/trx2.tar som/srv/TM1R${ext_3}.${ext_TM_dec}.info
     secure_command ${RM} -rf som/srv/TM1R${ext}.${ext_TM_dec}.info
     secure_command ${RM} -rf som/srv/TM1R${ext_3}.${ext_TM_dec}.info

     echo "Tarred trx binary" >> ${DEBUG_FILE}  

secure_command gzip --best ${TAR_PATH}/trx1.tar
secure_command gzip --best ${TAR_PATH}/trx2.tar
secure_command mv ${TAR_PATH}/trx1.tar.gz ${TAR_PATH}/trx1.tgz
secure_command mv ${TAR_PATH}/trx2.tar.gz ${TAR_PATH}/trx2.tgz

  echo "******************************************************"> \
  ${BUILD_PATH}/btspack_${pack_version}/btspack_log

  echo "********CONIFGURATION SPECS INFORAMTION********">> \
  ${BUILD_PATH}/btspack_${pack_version}/btspack_log



  $CLEARTOOL catcs >>  ${BUILD_PATH}/btspack_${pack_version}/btspack_log

  echo "******************************************************">> \
  ${BUILD_PATH}/btspack_${pack_version}/btspack_log


     if test "$1" = "1"
     then   


         echo " Making Build without any comparison">> \
         ${BUILD_PATH}/btspack_${pack_version}/btspack_log

         echo "SM1_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM2_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM3_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM4_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM5_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM6_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM7_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SM8_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SO1_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "SO2_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "TM1R${ext}_IR04.A5X :changed" >> ${INPUT_FILE}
         echo "TM1R${ext_3}_IR04.A5X :changed" >> ${INPUT_FILE}
         echo "RM1_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "RM2_IR04.A5X      :changed" >> ${INPUT_FILE}
         echo "RM3_IR04.A5X      :changed" >> ${INPUT_FILE}


     fi

     if test "$1" = "2"
     then 

         echo "Making Build by comparing binaries with previous build">> \
         ${BUILD_PATH}/btspack_${pack_version}/btspack_log

         binary_init 2 SM1 TAR_1 
         binary_init 2 SM2 TAR_2
         binary_init 2 SM3 TAR_SYS_3 
         binary_init 2 SM4 TAR_SYS_4
         binary_init 2 SM5 TAR_SYS_5 
         binary_init 2 SM6 TAR_SYS_6
         binary_init 2 SM7 TAR_SYS_7
         binary_init 2 SM8 TAR_SYS_8
	 binary_init 2 SO1 som1 
         binary_init 2 SO2 som2 
         # binary initialize for both the ciphering packages for dsp image
         binary_init 2 TM1R${ext} trx1
         binary_init 2 TM1R${ext_3} trx2
         binary_init 2 RM1 rfm1  
         binary_init 2 RM2 rfm2   
         binary_init 2 RM3 rfm3	

     fi 

  cd $CONFIG_BUILD
  echo "Config file generation for A50"
  #secure_command ./config_file_builder A50
  secure_command ./config_file_builder A50
  secure_command mkdir -p $CONF_PATH/ffs/run/som/srv
	secure_command mkdir -p $CONF_PATH/ffs/run/config/fct
  secure_command mv ep_som_cfg_file $CONF_PATH/ffs/run/som/srv/.
  secure_command cp -rf ${USR_LOCAL_DIR}/itrBuild/Variants/pcf.xml $CONF_PATH/ffs/run/config/fct/.
  secure_command chmod 666 $CONF_PATH/ffs/run/config/fct/pcf.xml
  cd $CONF_PATH
  secure_command ${TAR} -cf ${TAR_PATH}/btsconf_A50.tar ffs/*
  secure_command ${TAR} -tvf ${TAR_PATH}/btsconf_A50.tar >\
  ffs/run/som/srv/CFGR${ext}.${ext_BTS_CFG_dec}.info
  secure_command ${TAR} -rf ${TAR_PATH}/btsconf_A50.tar  \
  ffs/run/som/srv/CFGR${ext}.${ext_BTS_CFG_dec}.info
  echo "Tarred config file for A50" >> ${DEBUG_FILE}  
  secure_command ${RM} -rf ffs
  secure_command gzip --best ${TAR_PATH}/btsconf_A50.tar
  secure_command mv ${TAR_PATH}/btsconf_A50.tar.gz ${TAR_PATH}/btsconf_A50.tgz
  echo "gzipped config file for A50" >> ${DEBUG_FILE}  


  #Create conf tar and copy it in tar_files directory#
  #****************conf data A53*****************#
  #**********************************************#
  #**********************************************#
  #**********************************************#     

  cd $CONFIG_BUILD
  echo "Config file generation for A53"
  #secure_command ./config_file_builder A53
  secure_command ./config_file_builder A53
  secure_command mkdir -p $CONF_PATH/ffs/run/som/srv
	secure_command mkdir -p $CONF_PATH/ffs/run/config/fct
  secure_command mv ep_som_cfg_file $CONF_PATH/ffs/run/som/srv/.
  secure_command cp -rf ${USR_LOCAL_DIR}/itrBuild/Variants/pcf.xml $CONF_PATH/ffs/run/config/fct/.
  secure_command chmod 666 $CONF_PATH/ffs/run/config/fct/pcf.xml
  cd $CONF_PATH
  secure_command ${TAR} -cf ${TAR_PATH}/btsconf_A53.tar ffs/*
  secure_command ${TAR} -tvf ${TAR_PATH}/btsconf_A53.tar > \
  ffs/run/som/srv/CFGR${ext_3}.${ext_BTS_CFG_dec}.info
  secure_command ${TAR} -rf ${TAR_PATH}/btsconf_A53.tar \
  ffs/run/som/srv/CFGR${ext_3}.${ext_BTS_CFG_dec}.info
  secure_command ${RM} -rf ffs
  echo "Tarred config file for A53" >> ${DEBUG_FILE}  
  secure_command gzip --best ${TAR_PATH}/btsconf_A53.tar
  secure_command mv ${TAR_PATH}/btsconf_A53.tar.gz ${TAR_PATH}/btsconf_A53.tgz

  echo "gzipped config file for A53" >> ${DEBUG_FILE}  

  cd ${BUILD_PATH}

  # inserted for TRX A50
#secure_command cp som/trx/A50/trx1.tgz ${TAR_PATH}

  del_func tmp
  del_func ${ERROR_FILE}

  cd ${TAR_PATH}/
     secure_command create_af_files
  
     cd ${TAR_PATH}/

  echo "btsconf_version: ${btsconf_version}"

  secure_command  ../${AF_BUILD} -r"${ext}"${ext_BTS_CFG_dec} -n0 -e14 -V${btsconf_version} btsconf_A50.tgz >> ${BUILD_PATH}/btspack_${pack_version}/btspack_log

     secure_command ../${MF_BUILD} ${pack_version} "${ext}"${ext_BTS_CFG_dec}  SM* SO* RM* TM1R${ext}* CFGR${ext}.${ext_BTS_CFG_dec}  >> ${BUILD_PATH}/btspack_${pack_version}/btspack_log
  #                  SM4* SM5* SM6* SM7* \

     echo "globval: ${globVar}"
  echo "COOPING: ${btsconf_version}"
     secure_command cp ${packVar_A50} ${BUILD_PATH}/btspack_${pack_version}/A50/.
  secure_command cp CFGR${ext}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version}/A50/.
  secure_command cp BTSR${ext}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version}/A50/.
  secure_command ${RM} -f *.A50




  echo "Successfully created btspack_${pack_version} for A50"


     secure_command ../${AF_BUILD} -r"${ext_3}"${ext_BTS_CFG_dec} -n0 -e14 -V${btsconf_version_3} btsconf_A53.tgz >>  ${BUILD_PATH}/btspack_${pack_version_3}/btspack_log
     secure_command ../${MF_BUILD} ${pack_version_3} "${ext_3}"${ext_BTS_CFG_dec}  SM* SO* RM* TM1R${ext_3}* CFGR${ext_3}.${ext_BTS_CFG_dec}  >> ${BUILD_PATH}/btspack_${pack_version_3}/btspack_log

     secure_command cp ${packVar_A53} ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
  secure_command cp CFGR${ext_3}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version_3}/A53/.
  secure_command cp BTSR${ext_3}.${ext_BTS_CFG_dec} ${BUILD_PATH}/btspack_${pack_version_3}/A53/.

  secure_command ${RM} -f *.A53
  echo "Successfully created btspack_${pack_version_3} for A53"

  rm -rf  ${BUILD_PATH}/btspack_${pack_version_3}/btspack_log 
  echo "Deleted btspack_log from A53"
  chmod -R 755  ${BUILD_PATH}/btspack_${pack_version}
  chmod -R 755  ${BUILD_PATH}/btspack_${pack_version_3}

	#Updated SWCR1779
	echo "Do you want the targetBD package as well: yes, no"
	read choice
	if test ${choice} = "y" || test ${choice} = "Y" || test ${choice} = "yes"  \
		|| test ${choice} = "YES"
	then    
		echo " User selected to enter new versions">>${LOG_FILE}
		TARGET_BD_PATH=${BUILD_PATH}/ep_tools/bin
		TARGET_BD_BUILDER=${TARGET_BD_PATH}/target_bd_builder
		del_func ${BUILD_PATH}/btspack_targetBD_${pack_version_3}
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs/addons
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs/addons/fct
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs/run
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs/run/som
		secure_command mkdir ${BUILD_PATH}/btspack_targetBD_${pack_version_3}/ffs/run/som/srv
		BTS_WCDMA_PACKAGE_PATH=${BUILD_PATH}/btspack_targetBD_${pack_version_3}/
		secure_command chmod -R 755  ${BTS_WCDMA_PACKAGE_PATH}
		secure_command cd ${TAR_PATH}/
		secure_command mv TAR_1.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/trs_bin.tgz
		secure_command mv TAR_2.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/trs_lib.tgz
		secure_command mv som1.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/som_bin.tgz
		secure_command mv som2.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/som_lib.tgz
		secure_command cp rfm1.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/
		secure_command cp rfm2.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/
                secure_command cp rfm3.tgz ${BTS_WCDMA_PACKAGE_PATH}/ffs/addons/fct/
		secure_command cp CFGR1003.* ${BTS_WCDMA_PACKAGE_PATH}/ffs/run/som/srv
		secure_command ${RM} -f trx1.tgz
		secure_command ${RM} -f btsconf_A50.tgz
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/ffs/run/som/srv/
		secure_command tail -c +256 CFGR1003.${ext_BTS_CFG_dec} > CFGR1003_Update.${ext_BTS_CFG_dec}
		secure_command mv CFGR1003_Update.${ext_BTS_CFG_dec} CFGR1003.${ext_BTS_CFG_dec}
		secure_command ${TAR} -cvf cfg.tgz CFGR1003.${ext_BTS_CFG_dec}
		secure_command ${RM} -f CFGR1003.${ext_BTS_CFG_dec}
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/
		secure_command ${TAR} -cvf conf.tgz ffs/run/som/srv/cfg.tgz
		secure_command ${TAR} -tvf conf.tgz > conf.info
		secure_command ${RM} -f conf.tgz
		secure_command ${TAR} -cvf TGZFile.tgz ffs/addons/fct/*.tgz
		secure_command ${TAR} -tvf TGZFile.tgz > TGZFile.info
		secure_command ${RM} -f TGZFile.tgz

		for directory in ${TAR_PATH}/*.tgz
		do
			if [ -f "$directory" ] ; then
			  secure_command tar -xvf $directory -C ${BTS_WCDMA_PACKAGE_PATH}/
			fi
		done
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/
		secure_command ${RM} -f ffs/run/som/srv/CFGR1003.${ext_BTS_CFG_dec}.info
		#secure_command find ${BTS_WCDMA_PACKAGE_PATH}/ -name *.info > all_info_file_path.txt
		secure_command find . | grep info$ > all_info_file_path.txt
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/reassemble/
		secure_command cat lcpkernel.img.split* > lcpkernel.img
		secure_command cat uImage.initramfs.split* > uImage.initramfs
		secure_command cd ${TARGET_BD_PATH}/
		secure_command ${RM} -rf *.xml
		secure_command chmod -R 755  ${BTS_WCDMA_PACKAGE_PATH}
		secure_command ${TARGET_BD_BUILDER} ${ext_BTS_CFG_dec} ${pack_version_3}
		secure_command mv *.xml ${BTS_WCDMA_PACKAGE_PATH}
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/reassemble/
		secure_command ${RM} -f lcpkernel.img.split*
		secure_command ${RM} -f uImage.initramfs.split*
		secure_command ${RM} -f lcpkernel_*
		secure_command ${RM} -f uImage_*
		secure_command cd ${BTS_WCDMA_PACKAGE_PATH}/
		secure_command ${RM} -f *.info
		secure_command cd ${BUILD_PATH}/
		secure_command chmod -R 755  ${BTS_WCDMA_PACKAGE_PATH}
		#secure_command ${RM} -f ${BTS_WCDMA_PACKAGE_PATH}/all_info_file_path.txt
		secure_command ${RM} -f btspack_targetBD_${pack_version_3}.zip
		secure_command zip -r btspack_targetBD_${pack_version_3}.zip btspack_targetBD_${pack_version_3}/*
		#secure_command ${RM} -rf btspack_targetBD_${pack_version_3}
		echo "Successfully created btspack_targetBD_${pack_version_3}"
	else
		echo "User doesn't want to create targetBD package">>${LOG_FILE}  
	fi 
	#Ended SWCR1779
	echo "Exit trace, Function:create_build">> ${DEBUG_FILE}   
}


who am i > ${LOG_FILE}
 echo ${DATE} >>${LOG_FILE}
 echo platform: ${BLD_PLATFORM} >>${LOG_FILE}
 while [ /bin/true ]  
 do
     echo "Enter 1 to make build forcefully"
     echo "Enter 2 to make build by using comparison(with IB build)"
     echo "Enter 3 to exit application" 
     read option

     echo "User Selected option : $option" >>${LOG_FILE}
     if [[ "$option" = "1" || "$option" = "2" ]]
     then
         echo "Enter 1 to make Production Build"
         echo "Enter 2 to make Lab Build" 
         read option2
     fi
     echo "User Selected option (Production/Lab): $option2" >>${LOG_FILE}
     case "$option" in
         1) create_build  1 $option2 ;;
         2) create_build  2 $option2 ;;
         3) exit ;;
         *) echo "Wrong option Please enter option again" ;;
     esac
  done 

