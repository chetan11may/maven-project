#!/usr/bin/perl -w
use strict;
my $file="c++";
if($file=~/\+/)
{ 
$file=~/\+//g;
}
print $file;