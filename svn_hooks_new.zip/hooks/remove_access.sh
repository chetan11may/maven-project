cd /var/fpwork1/bts_builds/General/scripts/GF16_Trunk/hooks

svn up

rm -rf trunk_access_list

touch trunk_access_list

svn ci -m "updating the trunk access list and committers file"
