#!/usr/bin/perl
my $DEBUG_PRINT = 1;
my $jobName=$ARGV[0];
my $jobCommiterFilePath=$ARGV[1];
my $jobBuildNum = $ARGV[2];
my $jobBuildUrl = $ARGV[3];
my $jobFailureCause = $ARGV[4];
my $jobLogFile = "/var/fpwork_bkp1/jenkins_8080/jobs/".$jobName."/builds/".$jobBuildNum."/log";
my $filePath=$ARGV[1]."/".$ARGV[0].".committer";
my $SUBJECT="URGENT:::"."$jobName".":::FAILED!!";
my $EMAIL="";
my $EMAILMESSAGE="/tmp/testmail.txt";
my $tmpEmailFile="";
my $userEmail="";
my $groupMailList = "sunilkumar.md@nsn.com, nsn.btsman@nsn.com,I_MBB_SRAN_SW2_GSM_BTS_SLM@internal.nsn.com";
#my $aricentMailList = "soma.basu\@aricent.com,purna.ankala\@aricent.com,satheesh.narayanan\@aricent.com,rajiv2.singh\@aricent.com,kameshwar.samala\@aricent.com";
&DEBUG("committer file: $filePath");
my $userList = `cat $filePath`;
chomp($userList);
&DEBUG("userList:$userList");
if( $userList ne "")
{
## sending mail to culprits as well as SLM's , CI group and PC team
#my @userEmailList = ` finger $userList | grep email|cut -d= -f2|cut -f1`;
#foreach my $tmpuserEmail(@userEmailList)
#{
#chomp($tmpuserEmail);
#$userEmail.=$tmpuserEmail.",";
#}
#$userEmail .= $groupMailList.",";
#$userEmail .= $aricentMailList;
## email 
#open(tmpEmailFile,">$EMAILMESSAGE")||die "cannot open mail file";
#print tmpEmailFile "Hi All those Developers in the mailing list,\n\n      Your recent code commit(s) might have caused the Jenkins Job <<< $jobName >>> failure.\nFollowing users alone are allowed to commit to the respective repositories.\n\nPlease do the correction ASAP,\n\n" ;
#print tmpEmailFile `cat $filePath`;
#print tmpEmailFile "Regards \n DEV CI TEAM";
#close($tmpEmailFile);
#`/bin/mail -s $SUBJECT $userEmail < $EMAILMESSAGE`;
&DEBUG("calling funtion");
&sendCulpritMail();
}

sub DEBUG()
{
if($DEBUG_PRINT == 1)
{
	print "$_[0]";
	print "\n";
}

}

sub sendCulpritMail()
{
        my $mail_to_list = "suma.krishna\@nsn.com";
#        my $mailFrom = "gsmbtsscm\@bhling23.apac.nsn-net.net";
	my $mailFrom = "nsn.btsman\@nsn.com";
#        my $mailTo = $mail_to_list;
#       my $mailToCC =$groupMailList.",".$aricentMailList;
        my $mailToCC =$groupMailList;
#        my $mailToCC = "suhas.punuru\@nsn.com";
        my $datetime = `date`;
        my $subjectString = "";
        my $mail_body = "";
        chomp($datetime);
	$mail_body = "Hi, \n\n".
                        "NOTE : THIS IS AN AUTO-GENERATED MAIL FROM PRE-COMMIT SCRIPT: DO NOT REPLY!!!\n\n".
		"All those Developers in the TO Address list:\n".
		"You are receiving this mail due to $jobFailureCause Failure(s) in following Jenkins job which has used your recent code commit(s)\n";
	$mail_body = $mail_body . "\nJenkins Jobs : \t ".$jobName;
	$mail_body = $mail_body . "\nJenkins Job URL :\t ".$jobBuildUrl."\n\n";
	&DEBUG("job URL: $jobBuildUrl");
	$mail_body = $mail_body. "Stop and Fix is enabled for the following repositories and only the below mentioned users will be alllowed to check in code\n";
	open MYFILE ,"<", $filePath ;
	my $culpritList ="";
	my $printing_block_seperator ="----------------------------------------------------------------------------------------";
	while( <MYFILE>)
	{
		chomp($_);
		if($_ ne "")
		{
			my($repo,@culprits) =split(/,/,$_);
			$mail_body = $mail_body . $printing_block_seperator."\n\n";
			$mail_body =$mail_body."Repository :\t" .$repo."\n";
			&DEBUG("starting culprits loop :". scalar(@culprits));
			my $culMail = "";
			for(my $culIndex=0;$culIndex<scalar(@culprits);$culIndex++)
			{
				$culMail = `finger $culprits[$culIndex] | grep email|cut -d= -f2|cut -f1`;
				&DEBUG("culprit : $culprits[$culIndex] culprit mail : $culMail ");
				 if ( $culMail =~ s/no such user//)
				{
				}
				else
				{
					$culMail =~ s/^[\s\t]+//;
					$culMail =~ s/[\s\t]+$//; 
					$userEmail= $userEmail.$culMail.",";
				}
			}
			$culpritList=join(",  ",@culprits);
			$mail_body = $mail_body ."Possible Culprits :\t".$culpritList."\n\n";
			&DEBUG("all culprits : $culpritList");
			&DEBUG("all culprits mails : $userEmail");
		}	
	}
        my $mailTo = $userEmail;
	$mail_body = $mail_body . $printing_block_seperator."\n\n";
	$mail_body = $mail_body."Kindly check-in the correction ASAP so that the stop and fix is removed.\n\n";
	$mail_body = $mail_body."Please refer to the Attachment for a partial $jobName log file.\n\n";
	$mail_body = $mail_body."Best Regards,\n".
                        "BTS SCM\n";
	`tail -100 $jobLogFile > /tmp/jenkinsJobLogs/$jobName.log`;
#	`tail -100 /tmp/$jobName.log > /tmp/jenkinsJobLogs/$jobName.log`;
	&createHtmlLogFile();
        my $mailSub = "URGENT : JENKINS JOB << ". $jobName."\tBuild : #". $jobBuildNum ." >> Failed";
        `./mailsend_new -smtp mail.emea.nsn-intra.net +bc -cc \"$mailToCC\" +D -d nsn-intra.net -sub \"$mailSub\" -f \"$mailFrom\" -t \"$mailTo\" -M \"$mail_body\" -rt "nsn.btsman\@nsn.com" -attach \"/tmp/jenkinsJobLogs/$jobName.htm\",text/html,a`;
#my $mail_cmd='./mailsend_new -smtp mail.emea.nsn-intra.net +bc -cc "'.$mailToCC.'" +D -d nsn-intra.net -sub "'.$mailSub.'" -f "'.$mailFrom.'" -t "'.$mailTo.'" -M "'.$mail_body.'" -rt "nsn.btsman@nsn.com" -attach "/tmp/'.$jobName.'.htm",text/html,a';
print ("Executing : $mail_cmd \n");
system($mail_cmd);

}

sub createHtmlLogFile()
{
	my $htmlHead = "<HEAD><TITLE>.$jobName.log</TITLE></HEAD>";
	my $htmlBody = "<BODY>";
	my $inputFile = "/tmp/jenkinsJobLogs/$jobName.log";
	my $file = "/tmp/jenkinsJobLogs/$jobName.htm";
	open(LOG_FILE,"<$inputFile");
	open(MAIL_ATTACH,">$file")||die "cannot open mail file";
	print MAIL_ATTACH $htmlHead;
	print MAIL_ATTACH "<body lang=EN-US link=blue vlink=purple style='tab-interval:36.0pt'>\n";
	print MAIL_ATTACH "<div class=WordSection1>\n";
	print MAIL_ATTACH "<p class=MsoNormal><o:p>&nbsp;</o:p></p><table class=MsoNormalTable border=0 cellpadding=0 style='mso-cellspacing:1.5pt; mso-yfti-tbllook:1184'>";
	
	print MAIL_ATTACH " <td style='padding:.75pt .75pt .75pt .75pt'><p class=MsoNormal><b><span style='font-size:17.0pt;font-family:\"Verdana\",\"sans-serif\";color:black'>BUILD FAILURE</span></b><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\";color:black'><o:p></o:p></span></p> </td> </tr>";
	print MAIL_ATTACH "<tr style='mso-yfti-irow:1'> <td style='padding:.75pt .75pt .75pt .75pt'> <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\"; color:black'>Build URL<o:p></o:p></span></p> </td>";
	print MAIL_ATTACH "<td style='padding:.75pt .75pt .75pt .75pt'> <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\"; color:black'><a  href=\"$jobBuildUrl\">$jobBuildUrl</a><o:p></o:p></span></p>  </td> </tr>";
	print MAIL_ATTACH " <tr style='mso-yfti-irow:2'>  <td style='padding:.75pt .75pt .75pt .75pt'>  <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\";  color:black'>Project:<o:p></o:p></span></p>  </td>";
	print MAIL_ATTACH " <td style='padding:.75pt .75pt .75pt .75pt'>  <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\";  color:black'>$jobName<o:p></o:p></span></p>  </td> </tr>";

	print MAIL_ATTACH "<p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\";color:black'><o:p>&nbsp;</o:p></span></p>";
	print MAIL_ATTACH "<table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=\"100%\" style='width:100.0%;mso-cellspacing:0cm;mso-yfti-tbllook:1184;mso-padding-alt: 0cm 0cm 0cm 0cm'>";
	print MAIL_ATTACH " <tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'>";	print MAIL_ATTACH "<td style='background:#0000C0;padding:0cm 0cm 0cm 0cm'>";
	print MAIL_ATTACH " <p class=MsoNormal><b><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:white'>CONSOLE OUTPUT</span></b><span style='font-size:10.0pt;font-family:\"Verdana\",\"sans-serif\";color:white'><o:p></o:p></span></p> </td> </tr>\n";
	$rowIndex = 1;
	print MAIL_ATTACH " <tr style='mso-yfti-irow:$rowIndex'> <td style='padding:0cm 0cm 0cm 0cm'> <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Courier New\";  color:black'>[...Truncated Lines of console Output ..]<o:p></o:p></span></p>  </td> </tr>";
	while(<LOG_FILE>)
	{
		$rowIndex++;
		print MAIL_ATTACH " <tr style='mso-yfti-irow:$rowIndex'> <td style='padding:0cm 0cm 0cm 0cm'>  <p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Courier New\";color:black'>";
		print MAIL_ATTACH $_;
		print MAIL_ATTACH "<o:p></o:p></span></p>  </td> </tr>";
	}
	print MAIL_ATTACH "<p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Verdana\",\"sans-serif\";color:black'><o:p>&nbsp;</o:p></span></p></div></body></html>";

	close(MAIL_ATTACH);
}

