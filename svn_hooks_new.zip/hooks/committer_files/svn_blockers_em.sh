#!/bin/bash  


em_svn_url=$1
cl_svn_url=$2
job_name=$3
em_build_status=$4

if [ $# != 4 ]
then
echo "Usage svn_blocker.sh <em_svn_url> <cl_svn_url> <job_name> <build_status>"
exit 1
fi
svn up
source $HOOKS/hooks_${PRODUCT}_${BRANCH_TYPE}/committer_files/commit_details
rm -rf last_commiter commiter_new
echo $EM_BUILD_COMMITTER $CL_BUILD_COMMITTER $EM_COMMITTER $CL_COMMITTER
if [[ -z "${EM_BUILD_COMMITTER}" || -z "${CL_BUILD_COMMITTER}" || -z "${EM_COMMITTER}" || -z "${CL_COMMITTER}" ]];
then
echo "NO committer Email is set EM_BUILD_COMMITTER,CL_BUILD_COMMITTER,EM_COMMITTER,CL_COMMITTER"
#exit 1
fi
em_build_usr=$EM_BUILD_COMMITTER
cl_build_usr=$CL_BUILD_COMMITTER
cl_usr=$CL_COMMITTER
em_usr=$EM_COMMITTER


em_build_usr_email=$EM_BUILD_COMMITTER_EMAIL
cl_build_usr_email=$CL_BUILD_COMMITTER_EMAIL
em_usr_email=$EM_COMMITTER_EMAIL
cl_usr_email=$CL_COMMITTER_EMAIL

if [[ "$job_name" =~ "EM" ]] 
then
	echo $em_usr_email
	var=`echo $em_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com//'`
	echo $var
	grep -v $var committers > commiter_new
	if [ $em_build_status == "FAILURE" ]
	then
	echo `echo $em_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com//'`" ,$em_usr" >> commiter_new
	fi
	cp -rf commiter_new committers
	if [ $em_build_status == "FAILURE" ]
        then 
        echo "EM_LAST_COMMITTER=${em_usr_email}" >em_last_commiter
        cat em_last_commiter
        fi
fi
if [[ "$job_name" =~ "EM" ]] 
then
	echo $cl_usr_email
        var=`echo $cl_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com//'`
        echo $var
        grep -v $var committers > commiter_new
        if [ $em_build_status == "FAILURE" ]
        then
        echo `echo $cl_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com//'`" ,$cl_usr" >> commiter_new
        fi
        cp -rf commiter_new committers
        if [ $em_build_status == "FAILURE" ]
        then
        echo "CL_LAST_COMMITTER=${cl_usr_email}" >cl_last_commiter
	echo "LAST_COMMITTER=${em_usr_email},${cl_usr_email}" >last_commiter
        cat cl_last_commiter
	cat last_commiter
	fi
	
fi

svn ci -m"modifying the committers for $job_name" committers
