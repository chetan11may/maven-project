#!/bin/bash  

job_nam=$1
build_status=$2
product=$3
branch_type=$4
if [ $# != 4 ]
then
echo "Usage jenkin_job_blocker.sh <job_name> <build_status> <product> <branch_type>"
exit 1
fi


source /linux_builds/BTS_SW_Tools/GSM_CI_SCRIPTS/Properties/"$product"_"$branch_type"

if [ $build_status == "FAILURE" ]
        then
        echo "Blocking the Check change and Auto RFM update job"
		
		curl -X POST ${BUILD_TRIGGER_JOB}/disable --user ${JENKIN_LOGIN_ID}:${JENKIN_API_TOKEN}
		curl -X POST ${RFM_TRIGGER_JOB}/disable --user ${JENKIN_LOGIN_ID}:${JENKIN_API_TOKEN}
		sed -i -e "s/CI_JOB_FAILED=$CI_JOB_FAILED/CI_JOB_FAILED=$job_nam/" /linux_builds/BTS_SW_Tools/GSM_CI_SCRIPTS/Properties/"$product"_"$branch_type"

fi
if [ $build_status == "SUCCESS" ]
        then
        echo "Unblocking the Check change and Auto RFM update job"
		if [ $CI_JOB_FAILED == $job_nam ]
			then
			curl -X POST ${BUILD_TRIGGER_JOB}/enable --user ${JENKIN_LOGIN_ID}:${JENKIN_API_TOKEN}
			curl -X POST ${RFM_TRIGGER_JOB}/enable --user ${JENKIN_LOGIN_ID}:${JENKIN_API_TOKEN}
			sed -i -e "s/CI_JOB_FAILED=$CI_JOB_FAILED/CI_JOB_FAILED=None/" /linux_builds/BTS_SW_Tools/GSM_CI_SCRIPTS/Properties/"$product"_"$branch_type"
		fi
fi
