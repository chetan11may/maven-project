# ./svn_blockers.sh $job_nam success/failure

job_nam=$1
build_status=$2

if [ $job_nam == GF16_TRUNK_build -o $job_nam == GF16_TRUNK_SOM_UT -o $job_nam == GF16_TRUNK_SOM_UT ]
then
	if [ $build_status == FAILURE ] 
	then 	
	source ../../config.txt
	while read line    #reading line by line of GF16_Trunk_committer.txt
	 do
		#rm -rf commit.txt
        	comp1=`echo $line`      #component name
		echo "$line "
		svn log -l 1 $BHSCME_URL/$comp1 >GF16_Trunk_log.txt
		
        	last_changed_person=`cat GF16_Trunk_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
		#this will append the component name, Last changed Rev and url to BUILD_TAG.txt
	        echo -e "$comp1 ,$last_changed_person" >> commit.txt
        	echo "$comp1 ,$last_changed_person"
	 done < GF16_Trunk_committer.txt
	else
	
	while read line
	 do
		comp1=`echo $line`      #component name
		cat commit.txt | grep -v "$line ,*" >>commit_modify.txt
		rm -rf commit.txt
		mv commit_modify.txt commit.txt
	done < GF16_Trunk_committer.txt
	fi
elif [ $job_nam == GFC16_TRUNK_build -o $job_nam == GFC16_TRUNK_SOM_UT -o $job_nam == GFC16_TRUNK_TRS_UT ]
then
	if [ $build_status == FAILURE ]
        then
	source ../../../GFC16_Trunk/config.txt
        while read line    #reading line by line of GF16_Trunk_committer.txt
         do
                comp1=`echo $line`      #component name
                echo "$line "
                svn log -l 1 $BHSCME_URL/$comp1 >GFC16_Trunk_log.txt

                last_changed_person=`cat GFC16_Trunk_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
                #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
                echo -e "$comp1 ,$last_changed_person $url1" >> commit.txt
                echo "$comp ,$last_changed_rev1 $url1"
         done < GFC16_Trunk_committer.txt
        else

        while read line
         do
                comp1=`echo $line`      #component name
                cat commit.txt | grep -v "$line ,*" >>commit_modify.txt
                rm -rf commit.txt
                mv commit_modify.txt commit.txt
        done < GFC16_Trunk_committer.txt
        fi

elif [ $job_nam == GFC16_BLR_TRS_UT ]
then
        if [ $build_status == FAILURE ]
        then
        source ../../../GFC16_Trunk/config.txt
        while read line    #reading line by line of GF16_Trunk_committer.txt
         do
                comp1=`echo $line`      #component name
                echo "$line "
                svn log -l 1 $BHSCME_URL/$comp1 >GFC16_BLR_TRS_log.txt

                last_changed_person=`cat GFC16_BLR_TRS_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
                #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
                echo -e "$comp1 ,$last_changed_person" >> commit.txt
                echo "$comp1 ,$last_changed_rev1"
         done < GFC16_BLR_TRS_UT_committer.txt
        else

        while read line
         do
                comp1=`echo $line`      #component name
                cat commit.txt | grep -v "$line ,*" >>commit_modify.txt
                rm -rf commit.txt
                mv commit_modify.txt commit.txt
         done < GFC16_BLR_TRS_UT_committer.txt
        fi


elif [ $job_nam == GFC16_BLR_SOM_UT ]
then
        if [ $build_status == FAILURE ]
        then
        source ../../../GFC16_Trunk/config.txt
        while read line    #reading line by line of GF16_Trunk_committer.txt
         do
                comp1=`echo $line`      #component name
                echo "$line "
                svn log -l 1 $BHSCME_URL/$comp1 >GFC16_BLR_SOM_log.txt

                last_changed_person=`cat GFC16_BLR_SOM_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
                #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
                echo -e "$comp1 ,$last_changed_person" >> committers
                echo "$comp1 ,$last_changed_person"
         done < GFC16_BLR_SOM_UT_committer.txt
        else

        while read line
         do
                comp1=`echo $line`      #component name
                cat committers | grep -v "$line ,*" >>commit_modify.txt
                rm -rf committers
                mv commit_modify.txt committers
         done < GFC16_BLR_SOM_UT_committer.txt
        fi
elif [ $job_nam == GF16_BLR_TRS_UT ]
then
        if [ $build_status == FAILURE ]
        then
        source ../../../GFC16_Trunk/config.txt
        while read line    #reading line by line of GF16_Trunk_committer.txt
         do
                comp1=`echo $line`      #component name
                echo "$line "
                svn log -l 1 $BHSCME_URL/$comp1 >GF16_BLR_TRS_log.txt

                last_changed_person=`cat GF16_BLR_TRS_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
                #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
                echo -e "$comp1 ,$last_changed_person" >> commit.txt
                echo "$comp1 ,$last_changed_person"
         done < GF16_BLR_TRS_UT_committer.txt
        else

        while read line
         do
                comp1=`echo $line`      #component name
                cat commit.txt | grep -v "$line ,*" >>commit_modify.txt
                rm -rf commit.txt
                mv commit_modify.txt commit.txt
         done < GF16_BLR_TRS_UT_committer.txt
        fi


elif [ $job_nam == GF16_BLR_SOM_UT ]
then
        if [ $build_status == FAILURE ]
        then
        source ../../../GFC16_Trunk/config.txt
        while read line    #reading line by line of GF16_Trunk_committer.txt
         do
                comp1=`echo $line`      #component name
                echo "$line "
                svn log -l 1 $BHSCME_URL/$comp1 >GF16_BLR_SOM_log.txt

                last_changed_person=`cat GF16_BLR_SOM_log.txt | head -2 | tail -1 | cut -d" " -f3`

                                                                              #last changed rev
                #this will append the component name, Last changed Rev and url to BUILD_TAG.txt
                echo -e "$comp1 ,$last_changed_person" >> committers
                echo "$comp1 ,$last_changed_person"
         done < GF16_BLR_SOM_UT_committer.txt
        else

        while read line
         do
                comp1=`echo $line`      #component name
                cat committers | grep -v "$line ,*" >>commit_modify.txt
                rm -rf committers
                mv commit_modify.txt committers
         done < GF16_BLR_SOM_UT_committer.txt
        fi
fi
sort committers | uniq >commit_new.txt
rm -rf committers
mv commit_new.txt committers

