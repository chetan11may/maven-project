#!/bin/bash  

svn_url=$1
job_name=$2
build_status=$3


if [ $# != 3 ]
then
echo "Usage svn_blocker.sh <svn_url> <job_name> <build_status>"
exit 1
fi

rm -rf last_commiter commiter_new 
if [[ -z "${BUILD_COMMITTER}" || -z "${TRS_COMMITTER}" || -z "${SOM_COMMITTER}"  || -z "${BB_COMMITTER}" ]];
then
echo "NO committer Email is set BUILD_COMMITTER,TRS_COMMITTER,SOM_COMMITTER,BB_COMMITTER"
exit 1
fi
build_usr=$BUILD_COMMITTER
som_usr=$SOM_COMMITTER
trs_usr=$TRS_COMMITTER
bb_usr=$BB_COMMITTER

build_usr_email=$BUILD_COMMITTER_EMAIL
som_usr_email=$SOM_COMMITTER_EMAIL
trs_usr_email=$TRS_COMMITTER_EMAIL
bb_usr_email=$BB_COMMITTER_EMAIL
svn update

if [[ "$job_name" =~ "SOM" ]] 
then
	echo $som_usr_email
	var=`echo $svn_url | sed 's/https:\/\/bhscme.inside.nsn.com\(.*\)/\1\/som/'`
	echo $var
	grep -v $var committers > commiter_new
	if [ $build_status == "FAILURE" ]
	then
	echo `echo $svn_url | sed 's/https:\/\/bhscme.inside.nsn.com\(.*\)/\1\/som/'`" ,$som_usr" >> commiter_new
	fi
	cp -rf commiter_new committers
	if [ $build_status == "FAILURE" ]
        then 
        echo "LAST_COMMITTER=${som_usr_email}" >last_commiter
        cat last_commiter
        fi
elif [[ "$job_name" =~ "TRS" ]] 
then
	echo $trs_usr_email
	trs=`echo $svn_url | sed 's/https:\/\/bhscme.inside.nsn.com\(.*\)/\1/'`
	echo $trs
	#for comp in ` svn propget svn:externals $svn_som_url | awk '{print $2}' | grep -v "^$"`
	for comp in `svn ls $svn_url | grep "\/$" | grep -v som  | sed 's/\///'`
	do
	grep -v "$trs/$comp" committers > commiter_new
	if [ $build_status == "FAILURE" ]
        then
	echo "$trs/$comp"
	echo "$trs/$comp ,$trs_usr" >> commiter_new
	fi
	cp -rf commiter_new committers
	done
	if [ $build_status == "FAILURE" ]
        then 
        echo "LAST_COMMITTER=${trs_usr_email}" >last_commiter
        cat last_commiter
        fi
elif [[ "$job_name" =~ "BB" ]]
then
	bb_svn_url=`echo $svn_url | sed 's/sys/bb/'`
	echo $bb_usr_email
        var=`echo $bb_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com\(.*\)/\1\//'`
        echo $var
        grep -v $var committers > commiter_new
        if [ $build_status == "FAILURE" ]
        then
        echo `echo $bb_svn_url | sed 's/https:\/\/bhscme.inside.nsn.com\(.*\)/\1\//'`" ,$bb_usr" >> commiter_new
        fi
        cp -rf commiter_new committers
        if [ $build_status == "FAILURE" ]
        then
        echo "LAST_COMMITTER=${bb_usr_email}" >last_commiter
        cat last_commiter
	fi

fi

svn ci -m"modifying the committers for $job_name" committers
